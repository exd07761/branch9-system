# Changelog

All notable changes to this project are documented here, grouped by
milestone. Versions follow `MAJOR.MINOR.PATCH` loosely tied to milestone
completion during V1 development.

## [Unreleased] — IM-10: Case Activity & History

New, read-only Case Detail page giving the Clerk a single chronological
view of "what has happened with this case." No new Firestore collection,
no schema changes, no migration, no writes anywhere in this milestone —
everything shown is derived/read from data the app already had.

**Added**
- `case-detail.html` + `js/case-detail.js` — a new page (`case-detail.html?id=<caseId>`)
  showing a Case's identity fields plus an Activity & History timeline,
  reusing the existing `.timeline-*` CSS already used by Home's dashboard
  timeline and the existing `.card`/`.field` layout classes — no new CSS.
  Linked from a new "View" action per row on `cases.html`.
- `js/cases-data.js`: `getCase(caseId)` — one-shot fetch of a single Case
  document (no existing export returned a single full record).
- `js/activity-data.js`: `getActivityForEntities(entityType, entityIds)` —
  one-shot, entity-scoped query against the existing `activityLogs`
  collection (chunks `entityIds` into groups of 10 for Firestore's `in`
  operator limit). No changes to `activityLogs`' schema or to any
  existing export in this file.

**How the timeline is built** — three existing sources, merged and
sorted newest-first, nothing new stored:
1. Case-level `activityLogs` entries (Create/Edit/Archived Case).
2. Derived case status history (`hearings-data.js`'s existing
   `getCaseStatusHistory()`, IM-6B/Decision 008) — a Case's status
   changes, computed fresh from its linked Hearings.
3. Activity-log entries for every Hearing linked to the Case (via the
   existing `hearingCases.caseId` link, IM-6) — per the approved IM-10
   scope, hearing-generated activity is part of a case's history, not
   just edits to the Case document itself.

Deliberately **not** included: "Hearing rescheduled"/"Hearing cancelled"
event types — the data model has no such concept (only a workflow
`status`), so per IM-10's no-fabrication rule these are left out rather
than guessed at.

**Permissions**: items 1 and 3 above (raw `activityLogs` entries) are
only fetched/shown when the signed-in role has `activityLog.view` — the
same permission already gating the standalone Activity Log page — so
this page doesn't expose audit-log data to a role (Encoder, Read Only)
that can't already see it elsewhere. Item 2 (derived status history) is
domain data, not an audit log, and is always shown to anyone with
`cases.view`.

No changes to `hearings.js`, `hearings-data.js`, `case-status-derivation.js`,
`permissions.js`, `css/styles.css`, or any other existing page — confirmed
via diff against the prior milestone.

## [Unreleased] — IM-8: Hearing Workflow Refactor (Case-Centric)

Reviewed and approved via `HEARING_WORKFLOW_REFACTOR_PLAN.md` before any
code was written. Reorganizes the Add/Edit Hearing form around the Case
architecture — the free-text "Hearing type / purpose" field is retired
for new entries, and case rows are now linked to existing Cases instead
of free-typed. No changes to the Case schema, no migration logic
touched, no ADR revisited.

**Removed**
- The "Hearing type / purpose" field — input, required-field validation,
  and data collection all removed from `js/hearings.js`. Approved
  product decision, evidence-based (see the plan): the existing `status`
  dropdown already carries the granularity the field was informally
  trying to add (one of `STATUSES`' real values is literally
  "Continuation of the Direct Examination of Prosecution's Witness," the
  same phrase used to explain the workflow back in Decision 016's Clerk
  interview). Historical `hearingType` values on existing Hearing
  documents are untouched — this only stops the field being written
  going forward.
- The free-text duplicate-case-number check and its `confirm()` prompt —
  it existed to catch typos creating look-alike case numbers, a problem
  the Case picker (below) prevents structurally.
- `CASE_TYPES` constant — no longer used now that a case's type comes
  from the selected Case, not a free-typed dropdown.

**Added**
- **Case picker**: each case row in the Hearing form now selects from
  existing Cases (`cases-data.js`'s `subscribeToCaseRecords()`, IM-1,
  reused unchanged) instead of free-typing `caseType`/`caseNo`/`charge`/
  `dateFiled`. Selected Case's details display read-only for
  confirmation. On save, each row is linked via `setHearingCaseLink()`
  (IM-6, reused unchanged) — the identity fields are still denormalized
  onto the `hearingCases` row as before (unchanged for every existing
  reader of that data — reports, exports, search all keep working
  unmodified), just sourced from the selected Case now instead of typed.
- **Live status wiring**: after a successful save, `refreshCaseStatusFromHearings()`
  (IM-6B) is called for each linked Case. This is the one genuinely new
  piece of logic in this milestone — everything else is existing,
  already-tested functions used from a new place. Previously this
  function had zero callers anywhere in the live app (IM-6B and IM-7A
  both only ever called it from the offline migration tool) — a Case's
  `currentStatus` now stays accurate as new hearings are added day to
  day, not only at migration time.
- The pre-existing "Notes" field (already in this file before this
  milestone) is the approved home for anything `hearingType` used to
  capture that `status`/`section` don't — verified, not assumed, that it
  was already excluded from search (`hearingMatchesSearch`), reporting
  (`reports-data.js`), and derivation (`case-status-derivation.js`)
  before this milestone touched anything. Relabeled "Notes / Remarks"
  with a clarifying placeholder; no behavioral change.

**Fixed (naming, not behavior)**
- `formCaseRows[i].caseId` — a pre-existing, pre-v1.1 field meaning "this
  `hearingCases` row's own document id" — collided with IM-6's unrelated
  `hearingCases.caseId` field ("the Case this row is linked to"). Same
  name, two unrelated meanings, in a file no Phase 1 milestone had
  touched until now. Renamed to `hearingCaseRowId`; the real Case link
  is now the separate, correctly-named `linkedCaseId`.
- `hearings-data.js`'s `saveHearing()` — parameter renamed to match, and
  it now returns `{ hearingId, rowIds }` instead of a bare hearing id
  string, so its one caller can learn each row's resulting id (including
  newly-created ones) and link them afterward. Confirmed via search that
  `hearings.js` is this function's only caller anywhere in the app, so
  this return-shape change is safe.
- Quick View's preview title: falls back to `status` instead of a bare
  "Hearing" when `hearingType` is absent (every new hearing, going
  forward) — otherwise every new hearing's preview would show a
  generic, uninformative title.

**Verified before delivery**
- Full syntax check on both modified files.
- Traced every caller of `saveHearing()` in the codebase (one — this
  file) before changing its return shape.
- Simulated the row-id/linked-Case pairing logic (existing rows keep
  their id, new rows get a fresh one, order preserved end to end)
  against a synthetic mixed scenario — correct.
- Swept for stale references to every removed identifier (`hearingType`,
  `CASE_TYPES`, the old free-text case-row field classes, the old
  colliding `caseId` meaning) — none remain outside intentional,
  historical-compatibility code paths and documentation comments.
- Confirmed `docx-export.js` and `reports-data.js` (both out of scope,
  not modified) already handle an empty `hearingType` safely — the
  Hearing Order export will show a blank line where the type used to
  print for new hearings; not fixed here, flagged as a possible future
  cosmetic follow-up, not a defect.
- Confirmed the new `.case-picker` `<select>` needs no new CSS — the
  existing generic `.field select` rule already styles it.

**Not changed:** `js/cases-data.js`, `js/case-status-derivation.js`,
`hearings.html` (the form is entirely rendered dynamically from
`hearings.js` — no static markup to change), `cases.html`, `cases.js`,
`migration-execute.js`, `migration-dryrun.js`, `DECISIONS_v1.1.md`,
`IMPLEMENTATION_READY.md`, and every other existing file — all confirmed
byte-identical by diff.

## [Unreleased] — Bug fix: `migration-dryrun.js` crashed when imported by `migration-execute.js`

Found during IM-7A's first real execution. `migration-dryrun.js`'s
file-input wiring ran unconditionally at module-import time, assuming
`#fileInput` (and `#downloadBtn`, inside `renderReport()`) always exist.
`migration-execute.js` imports this file's `buildAnalysis()` but has
neither element on its own page (`migration-execute.html`), so opening
it threw `TypeError: Cannot read properties of null (reading
'addEventListener')` before anything else could run.

**Fixed:** both `addEventListener` call sites are now guarded behind an
element-existence check. Confirmed the original code reproduces the
exact reported error in a minimal DOM stub, and that the fixed code
does not, before and after this change. `buildAnalysis()`'s own
behavior is unchanged — re-verified against the same sample data used
in earlier testing, with identical output.

**Changed:** `js/migration-dryrun.js` only. No other file touched; no
change to any analysis or migration logic, `DECISIONS_v1.1.md`, or
`IMPLEMENTATION_READY.md`.

## [Unreleased] — IM-7A: Pilot Migration Tool

**Reviewed and frozen.** Final implementation review confirmed every core
production-safety requirement — explicit operator action, no automatic
execution, no destructive writes, the idempotency guard, manifest
generation, and pilot-mode support — is implemented and verified working.
Two non-blocking gaps were found against `IM7_PLANNING.md` and are tracked
as follow-up, not reopened here: (1) `buildAnalysis()`'s
`caseNoUnderMultipleTypes` signal (same-case-number-under-different-
case-type) is computed but not yet surfaced to the operator, the way
ambiguous groups already are — recommended before the first *full*
(non-pilot) run; (2) the current `cases` collection count isn't displayed
during analysis, though the idempotency guard already covers the
underlying safety goal that check was meant to protect. No production
files outside this milestone's stated scope were modified; no
architecture decisions were revisited.

First implementation milestone after `IM7_PLANNING.md` was reviewed and
approved. Implements only the pilot migration tool — no full production
migration was run, no rollback tooling exists yet, and no ADR was
changed. Reuses existing, already-tested functions wherever possible
rather than re-implementing their logic.

**Added**
- `migration-execute.html` + `js/migration-execute.js` — standalone,
  write-capable migration tool. Requires sign-in and the
  Administrator-only `BACKUP_MANAGE` permission (the same one
  `backup.html` already gates behind — no new permission invented).
  Not linked from the Clerk-facing app or its nav. Opening the page
  does nothing by itself: analysis and migration both require an
  explicit button click, and migration additionally requires confirming
  a dialog before any write occurs.
  - **Analysis (read-only):** reads all `hearings`/`hearingCases` live
    and reuses `migration-dryrun.js`'s `buildAnalysis()` (see below) to
    group them into candidate Cases, exactly as the read-only dry-run
    tool already does — against live data instead of a backup file.
  - **Idempotency guard:** before migrating a candidate group, every
    member row is checked for an already-set `caseId`. If any member
    already has one, the whole group is skipped as "already migrated" —
    including a partially-linked group, deliberately, since silently
    finishing a partial group risks creating a second Case for a
    real-world case already linked to a different one. This also makes
    a re-run after an interrupted run safe: only not-yet-migrated groups get
    processed.
  - **Ambiguous groups are skipped, not auto-created** with a best
    guess — recorded in the manifest for manual creation via
    `cases.html` instead.
  - **Pilot limit:** an optional cap (a plain number input, blank =
    unlimited) on how many groups get migrated in one run.
  - **Migration sequence per eligible group:** `createCaseShell()` →
    `setHearingCaseLink()` for each linkable member row →
    `refreshCaseStatusFromHearings()` → `logActivity()` → recorded in
    the in-memory manifest. One group's failure (caught per-group) does
    not stop the rest of the run — recorded under "errors" instead.
  - **Downloadable migration-run manifest** (JSON): every created
    Case's id/identity/linked rows/derived status, every skipped group
    (already-migrated, ambiguous, or not-reached-this-run under a
    pilot limit) with its reason, and every error.
  - **Post-run summary** on-page: cases created, hearing links created,
    groups skipped (broken out by reason), errors encountered — exactly
    the categories requested.
- `js/hearings-data.js`: two new one-shot, read-only bulk fetches —
  `getAllHearings()` and `getAllHearingCaseRows()` — used only to build
  `buildAnalysis()`'s input from live data. Neither filters or writes
  anything.
- `js/cases-data.js`: `createCaseShell(caseData)` — creates a Case with
  identity fields only; `currentStatus`/`currentStatusDate` are
  deliberately left unset rather than given a placeholder, so the
  immediately-following `refreshCaseStatusFromHearings()` call is what
  actually determines them, from the Case's real Hearing history.
- `js/migration-dryrun.js`: **one-line change** — `buildAnalysis()` is
  now `export`ed. Nothing else in this file changed; it still only ever
  reads a local file and never touches Firestore. This lets
  `migration-execute.js` reuse the exact same, already-tested
  grouping/ambiguity logic against live reads instead of duplicating it.

**Verified (not assumed) before delivery**
- The live-data adapter (converting a Firestore Timestamp into the
  tagged shape `buildAnalysis()` expects from a backup file) was tested
  end-to-end against synthetic data standing in for a live read: a
  clean 2-hearing group, a group whose only hearing was soft-deleted
  (correctly flagged ambiguous by `buildAnalysis()` AND correctly
  excluded from linkable rows), and a group with a pre-existing `caseId`
  (correctly detected as already migrated) — all categorized correctly.
- The deterministic sort order and pilot-limit slicing were tested in
  isolation against synthetic candidates — correct in both cases.

**Not implemented (by design — see `IM7_PLANNING.md`)**
- No rollback tooling — that's explicitly out of this milestone's scope.
  The pre-migration backup this tool repeatedly asks the operator to
  confirm is the only safety net right now.
- No full production migration was run as part of building this.
- No staging/test Firebase project was stood up — `IM7_PLANNING.md`'s
  §7 finding about this gap still stands, unaddressed.
- The `cases.js` status-fallback wrinkle (`IM7_PLANNING.md` §2/§9) is
  still unresolved — the post-run report explicitly calls out any
  created case with no derived status, since that's exactly the case
  that would hit it, but nothing here fixes the underlying UI default.

**Not changed:** every existing Hearing/hearingCases/activityLogs/users/
systemStatus/cases document, every Firestore Security Rule, every ADR in
`DECISIONS_v1.1.md`, `IMPLEMENTATION_READY.md`, and every other existing
file (including `migration-dryrun.html`, unchanged).

**Files confirmed byte-identical:** every existing file except
`js/hearings-data.js`, `js/cases-data.js`, and `js/migration-dryrun.js`
(all additive/minimal), plus two new files,
`migration-execute.html` and `js/migration-execute.js`.

## [Unreleased] — IM-6B: Status Derivation

First implementation milestone after Phase 0's full architecture freeze
(all 19 decisions Accepted/Accepted Risk, none Deferred). Implements the
behavior Decisions 008 and 016 describe, now that both are resolved.
Additive only — no migration code, no UI changes, no changes to any
accepted ADR.

**Added**
- `js/hearings-data.js`: `getCaseStatusHistory(caseId)` — derives a
  Case's status history by reading its linked Hearings (via the
  existing `getHearingCaseRowsForCase()`, then each row's parent
  Hearing document), sorted chronologically by `hearingDateTime`. This
  IS Decision 008's Option (b) — no separate history log exists
  anywhere; this function computes history fresh from the Hearing
  records each time it's called. Excludes soft-deleted Hearings,
  includes archived ones (archiving is a view-layer state, not data
  removal — an archived Hearing is still real history). Read-only; does
  not write to `cases`, `hearings`, or `hearingCases`.
- `js/cases-data.js`: `applyDerivedCurrentStatus(caseId, currentStatus, currentStatusDate)`
  — writes an already-derived status onto a Case. No-op (no write at
  all, not even audit fields) if the status hasn't actually changed,
  mirroring `saveCase()`'s existing Decision 007 rule. Deliberately
  dates the change to the source Hearing's own `hearingDateTime` rather
  than `serverTimestamp()` — a derived status change is dated to when
  the procedure actually happened, not to whenever this function
  happened to run. This is a different (and, for this write path,
  correct) meaning for the same field than `saveCase()`'s manual-edit
  path uses, which has no hearing date to attach to and keeps using
  `serverTimestamp()`.
- `js/case-status-derivation.js` (new file) — the orchestration layer
  tying the two together, so neither data file has to import the
  other in both directions:
  - `deriveCurrentStatusFromHistory(history)` — pure, no Firestore
    access: the chronologically last entry in a status history is the
    derived current status/date, per Decision 016 (a Hearing's status
    represents the procedure being conducted at that hearing, advancing
    only on a genuine stage change — resolved via Clerk interview).
    Tested against synthetic data before delivery (empty history, single
    entry, multi-entry ordering) — see conversation for output.
  - `refreshCaseStatusFromHearings(caseId)` — orchestrates history →
    derive → apply. A Case with no linked Hearings yet is left
    completely untouched (no write, nothing cleared) — "no history yet"
    is not treated as "no status."

**Verified (not assumed) before delivery**
- The filter/sort logic inside `getCaseStatusHistory()` was tested in
  isolation against synthetic hearing records: soft-deleted entries are
  excluded entirely, chronological ordering is correct, and an entry
  with no usable date sorts last rather than breaking the ordering or
  silently disappearing.
- `deriveCurrentStatusFromHistory()` was tested against an empty
  history, a single-entry history, and a multi-entry history — all
  behaved as documented.

**Known limitation, named rather than silently handled:** if two
Hearings linked to the same Case share the exact same
`hearingDateTime` — observed in real production data during IM-5 (case
7009) — which one is treated as "later" depends on query result order,
which Firestore does not guarantee stable. No business rule exists to
break such a tie, so none is invented here.

**Not implemented (by design — see `DECISIONS_v1.1.md`)**
- No caller anywhere invokes `refreshCaseStatusFromHearings()` yet —
  same posture as IM-6's `setHearingCaseLink()`, which also shipped
  with zero callers. Wiring this into an actual trigger point (a
  Hearing save, a migration run, a manual recompute action) is future
  work.
- No migration code — IM-7's scope, not this milestone's.
- No UI changes anywhere.
- No status-transition validation (never-backwards/never-skips/plea-
  bargaining-once) — that remains separate future work, not part of
  status *derivation*.

**Not changed:** every existing Hearing/hearingCases/activityLogs/users/
systemStatus/cases document, every Firestore Security Rule, every ADR in
`DECISIONS_v1.1.md`, and every other existing file.

**Files confirmed byte-identical:** every existing file except
`js/hearings-data.js` and `js/cases-data.js` (both additive), plus one
new file, `js/case-status-derivation.js`.

## [Unreleased] — IM-6: Hearing↔Case Structural Linkage

Sixth milestone of Phase 1 implementation (IM-5 was an evidence-review/
ADR milestone with no code, so has no entry here). Approved narrowly,
per explicit scope from review: establish Hearing↔Case references,
introduce linkage fields, preserve referential integrity, prepare the
schema for migration — and nothing more. Explicitly out of scope and
not present anywhere in this milestone: deriving or modifying
`currentStatus`, any workflow-transition logic, any inference from
`status`/`hearingType`/`section`, and no implicit resolution of
Decisions 016/017/018 (all three remain Deferred, untouched by this
milestone).

**Added**
- `js/hearings-data.js`: `caseId` (optional) on `hearingCases` rows —
  absent on every row that existed before this milestone, and stays
  absent until explicitly set. Three new functions, and nothing else
  changed in this file:
  - `setHearingCaseLink(hearingCaseId, caseId)` — writes the reference,
    after confirming (referential integrity) that the target Case
    actually exists via `cases-data.js`'s new `caseExists()`. Throws
    rather than writing a dangling reference if it doesn't.
  - `clearHearingCaseLink(hearingCaseId)` — clears a reference back to
    `null`.
  - `getHearingCaseRowsForCase(caseId)` — one-shot (not live) lookup of
    every `hearingCases` row currently linked to a Case.
  None of the three read, derive, or write `currentStatus` or
  `currentStatusDate`, and none read `status`, `hearingType`, or
  `section`.
- `js/cases-data.js`: `caseExists(caseId)` — a small existence check,
  added so `hearings-data.js` never has to read the `cases` collection
  directly, preserving the one-file-per-collection convention. Also
  corrected one now-stale comment (previously cited Decision 015 as a
  reason a field was withheld; Decision 015 was resolved Accepted in
  IM-5, so the note was updated to cite Decision 016 alone, which is
  what actually still applies).

**Verified (not assumed) before delivery**
- The existing `hearingCases` Firestore Security Rule already gates by
  action (`create`/`update`/`delete` via `canEditHearings()`), not by
  specific field names — so the new `caseId` field needed **no**
  Firestore rule change. Confirmed by reading the current rule, not
  assumed.
- `backup-data.js` already backs up and restores `hearingCases`
  documents generically (whole-document, field-agnostic) — so `caseId`
  is automatically included in future backups with **no** change to
  that file either.

**Not implemented (by design — see `DECISIONS_v1.1.md`)**
- No UI anywhere for setting or viewing a link — this milestone is
  data-access-layer only, same discipline IM-1 used (data layer first,
  UI deferred). Nothing currently calls `setHearingCaseLink()`.
- No cascading behavior if a linked Case is later archived or
  soft-deleted — the reference is left exactly as it is; Cases are
  never hard-deleted, so nothing can dangle as a result.
- No automatic linking during Hearing save — linking is only ever
  explicit, via a direct call to `setHearingCaseLink()`.

**Not changed:** every IM-1/IM-2/IM-3/IM-4 file and document not listed
above, every existing Hearing/hearingCases/activityLogs/users/
systemStatus/cases document, and every Firestore Security Rule.

**Files confirmed byte-identical:** every existing file except
`js/hearings-data.js` and `js/cases-data.js`, both additive changes
described above (full diffs available on request).

## [Unreleased] — IM-4: Migration Design & Non-Destructive Dry Run

Fourth milestone of Phase 1 implementation (Decision 005). Does not touch
IM-1/IM-2/IM-3 files at all. No Firestore access of any kind — this
milestone never connects to the database, reads only a local file the
user selects themselves.

**A scoping note, not a scope change:** the roadmap describes this
milestone as running the dry run "once" and producing "a written
report." Since this app's data is real court records, a one-time report
generated by running it against a copy of production data isn't the
right shape — instead, this milestone delivers the reusable tool itself.
The Clerk/developer runs it, as many times as useful, against whichever
Backup & Restore export is current, entirely inside their own browser
tab. Nothing is uploaded anywhere as part of building or reviewing this
tool.

**Added**
- `migration-dryrun.html` + `js/migration-dryrun.js` — standalone
  developer tool, same standing as `diagnostics.html` (not linked from
  anywhere in the Clerk-facing app, no `requireAuth()`, not part of the
  nav). Carries an explicit on-page notice, added before freeze at
  review request: analysis-only, no migration, no Firestore calls of
  any kind, sole purpose is generating evidence for the IM-5 Business
  Validation Checkpoint (Decisions 009/015/016/017/018 — the original
  notice omitted Decision 009 by mistake, now corrected). Reads a
  Backup & Restore export file (`backup.html`) and reports:
  - How many candidate Cases reconstruct cleanly vs. need a human look
    (inconsistent charge/dateFiled across a case's hearings, missing
    hearingDateTime, empty status), per Decision 005's migration
    strategy.
  - Direct evidence for Decision 015 (Hearing-to-Case cardinality): how
    many hearings have more than one case row attached, with examples.
  - Direct evidence for Decision 009's still-pending validation: real
    frequency tables of the `status`/`hearingType`/`section` values
    actually in use.
  - Targeted evidence for Decisions 017/018 (Plea Bargaining /
    Provisionally Dismissed placement): every hearing whose `status` or
    `hearingType` mentions plea bargaining, provisional status, or
    dismissal, for manual inspection.
  - A downloadable full JSON report for archiving alongside whatever
    IM-5 discussion it informs.
  - Tested against synthetic sample data (not real records) to confirm
    the grouping/reconstruction logic behaves as intended before
    delivery — multi-hearing case grouping, inconsistent-field
    detection, orphaned-row and missing-case-number exclusion, and
    keyword detection all verified.

**Not implemented (by design)**
- No "run migration" button anywhere on this page — it never writes to
  Firestore, staging or production. That's IM-7, after IM-5 closes.
- Does not resolve Decisions 015/016/017/018 itself — it produces
  evidence toward the IM-5 Business Validation Checkpoint, not a
  decision.

**Not changed:** every IM-1/IM-2/IM-3 file, every existing Hearing/
hearingCases/activityLogs/users/systemStatus/cases document, page, and
Firestore rule.

**Files confirmed byte-identical:** every existing file except the two
new files added above.

## [Unreleased] — IM-3: Backup & Restore Versioning

Third milestone of Phase 1 implementation (Decision 011). Does not touch
IM-1's or IM-2's files at all. No existing Hearing/hearingCases document,
page, or Firestore rule changed.

**A finding that shaped this milestone's actual scope:** the version
marker Decision 011 called for already existed in v0.9.4
(`backupVersion`/`systemVersion`, both stamped on export, validated on
restore, and already displayed to the user before they confirm a
restore) — so there was nothing to invent there. What was actually
missing: `cases` (added in IM-1) wasn't in `backup-data.js`'s collection
list yet, so a backup taken today would have silently excluded all Case
data. That's the real gap this milestone closes.

**Added**
- `js/backup-data.js`: `cases` added to `ALL_COLLECTIONS` (now backed up
  and restored, `"upsert"` policy — same as `hearings`/`hearingCases`/
  `users`) and `BACKUP_VERSION` bumped `"1.0"` → `"1.1"` to mark that the
  backup schema changed. `ALL_COLLECTIONS` is now exported (was
  file-local) so `validateBackupFile()` can compute a new
  `summary.missingCollections` — any collection this app currently
  tracks that a loaded file doesn't have (e.g. `cases`, in any backup
  from before this milestone). Verified (not assumed): the existing
  Timestamp (de)serialization is field-name-agnostic — it already
  handles `currentStatusDate` correctly with no code change, since it
  detects Timestamps structurally, not by field name.
- `js/backup.js`: renders `missingCollections` in both the
  file-validation summary and the restore confirmation dialog — e.g.
  "This backup does not include: cases (created before this backup
  format tracked it)." A 1.0 backup remains fully valid and restorable;
  this only makes explicit what it won't bring back, per
  `DECISIONS_v1.1.md` Decision 011's "clear, honest messaging"
  requirement. No new CSS — reuses the existing `.muted` class rather
  than adding a new one.

**Not changed:** every IM-1/IM-2 file (`js/cases-data.js`,
`js/permissions.js`, `README.md`, `cases.html`, `js/cases.js`, and the
Cases nav link on all 9 pages), every existing Hearing/hearingCases/
activityLogs/users/systemStatus document, page, and Firestore rule.

**Flagged, not fixed (out of this milestone's scope):**
`js/backup.js`'s `SYSTEM_VERSION` constant is still hardcoded to
`"0.9.4"`, even though the app's actual `VERSION` file now reads
`"1.0.0"` — a pre-existing discrepancy from before Phase 1, unrelated to
the version-marker mechanism this milestone addresses. Left as-is rather
than silently fixed while this file was already open; worth a
one-line fix in a future milestone if confirmed as a genuine defect.

**Files confirmed byte-identical:** every existing file except
`js/backup-data.js` and `js/backup.js`, both additive-only changes
described above.

## [Unreleased] — IM-2: Case Management UI

Second milestone of Phase 1 implementation. Adds a standalone Case
Management page (add/edit/list/archive). Does not touch IM-1's
`cases-data.js`, `permissions.js`, or `README.md` — those remain exactly
as reviewed and frozen. No existing Hearing/hearingCases document, page
logic, or Firestore rule changed.

**Added**
- `cases.html` + `js/cases.js` — new page, mirroring `hearings.html`/
  `hearings.js`'s shell, form, table, and permission-gating conventions.
  Add/Edit/Archive Case, required-field validation (Case No., Current
  Status), duplicate-case-number warning (same UX as Hearings' — a
  `confirm()` prompt, not a hard block), status dropdown limited to the
  confirmed workflow sequence only (Case Filed through Decided — Plea
  Bargaining and Provisionally Dismissed intentionally excluded; their
  placement is Decision 017/018, still Deferred).
- A "Cases" nav link (`data-permission="cases.view"`), added to every
  existing page's nav bar (`home.html`, `hearings.html`, `calendar.html`,
  `activity.html`, `reports.html`, `users.html`, `archived.html`,
  `backup.html`) and to `cases.html` itself — one line inserted per file,
  confirmed by diff against the prior release to be the only change to
  each of those 8 files.

**Not implemented (by design — see `DECISIONS_v1.1.md`)**
- No Hearing linkage, no status-transition validation, no migration —
  same exclusions as IM-1, still scheduled for IM-6/IM-7.
- No search bar, no Quick View modal, no Export — narrower than
  `hearings.html` on purpose; nothing here prevents adding them later.
- No "Archived Cases" page (would mirror `archived.html`) — Archive is
  one-way from this page's list for now; `restoreCase()` already exists
  in `cases-data.js` (IM-1) for whenever that page is built.
- The duplicate-case-number check is implemented inside `cases.js`
  itself (scanning the already-loaded in-memory list) rather than as a
  new `cases-data.js` export — deliberately, to avoid any diff to the
  frozen IM-1 file.

**Not changed:** `js/cases-data.js`, `js/permissions.js`, `README.md`
(IM-1's files — no diff to any of them in this milestone), every
existing Hearing/hearingCases/activityLogs/users/systemStatus document
and Firestore rule.

**Files confirmed byte-identical:** every existing file except the 8
listed above (one inserted nav line each, confirmed by diff).

## [Unreleased] — IM-1: Case Collection Foundation

First milestone of Phase 1 implementation under the v1.1 architecture
redesign (see `DECISIONS_v1.1.md`, `IMPLEMENTATION_ROADMAP.md`). Adds
only the Case collection's data-access foundation. Not a redesign, not
a migration, no existing collection's schema changed, no existing page
or Hearing document touched. **Versioning note:** left under
`[Unreleased]` rather than assigned a version number — IM-1 ships no
page and nothing yet imports `cases-data.js`, so there's no version
string anywhere that needs to reference it yet, and whether each
Phase 1 milestone gets its own version bump (as v0.9.0–v0.9.9 each did)
or the whole phase is versioned once at the end is an open question,
not decided here.

**Added**
- New Firestore collection: `cases` (only new collection — `hearings`,
  `hearingCases`, `activityLogs`, `users`, and `systemStatus` are
  untouched, no migration, no schema changes to any of them). This is
  the new Case aggregate root from the v1.1 redesign (Decision 001) —
  a separate concept from a `hearingCases` row; see `cases-data.js`'s
  header comment for the full distinction.
- `js/cases-data.js` — the only file that reads or writes `cases`.
  Exports `subscribeToCaseRecords()`, `subscribeToArchivedCaseRecords()`,
  `saveCase()`, `deleteCase()`, `archiveCase()`, `restoreCase()`, and
  `isActiveCase()`, matching `hearings-data.js`'s naming and
  `writeBatch` pattern exactly — except the two live-listener functions,
  which are named `...CaseRecords()` rather than `...Cases()` to stay
  clearly distinct from `hearings-data.js`'s existing `subscribeToCases()`
  (a different concept — a `hearingCases` row, not the new Case
  aggregate root). No UI code in this file.
- `js/permissions.js` — added `CASES_VIEW`/`CASES_CREATE`/
  `CASES_EDIT`/`CASES_DELETE` permissions, mapped into the existing
  role matrix with the same role sets as the equivalent `HEARINGS_*`
  permissions. Archiving a Case reuses the existing `ARCHIVE_MANAGE`
  permission rather than adding a new one. No page checks these
  permissions yet.
- `README.md` — added the `cases` collection's Firestore Security Rule,
  and `canEditCases()`/`canDeleteCases()` helper functions (same role
  sets as their Hearings equivalents). Reuses the existing
  `isSoftDelete()`/`isArchiveChange()`/`canArchiveHearings()` helpers
  as-is.

**Not implemented (by design — see `DECISIONS_v1.1.md`)**
- Case status history / transition log (Decision 008 is Deferred)
- Any reference between a Case and a Hearing document (Decision 002/015
  is still Deferred)
- Migration or backfill from existing `hearingCases` documents
  (scheduled for IM-4/IM-7)
- Status-transition validation — never-backwards/never-skips/plea-
  bargaining-once (scheduled for IM-6, once Decisions 015–018 resolve)
- Any Case Management UI or page (scheduled for IM-2)
- Activity logging calls — there is no page controller yet to call
  `logActivity()` from; `cases-data.js` itself never calls it, matching
  the existing convention that data-access files never log activity
  themselves

**Not changed:** every existing collection's schema, every existing
page, every existing Security Rule (`hearings`, `hearingCases`,
`activityLogs`, `users`, `systemStatus` rules are byte-identical to
v1.0.0).

**Files confirmed byte-identical:** every existing file in the
repository except `js/permissions.js` and `README.md`, both of which
received additive-only changes described above.

## [1.0.0] — Stable Release

The first stable release of Branch9 Docket Management System. This is a
packaging release only — every feature, fix, and polish pass below was
already completed and shipped incrementally across v0.1.0–v0.9.9; v1.0.0
bumps the version, consolidates the release notes, and confirms nothing
was missed on the way to a first public stable build. No business logic,
Firestore schema, or UI behavior changed in this release.

**Completed feature set, by area (see each version's own entry above
for full detail):**
- **Authentication** — Firebase Auth email/password sign-in, session
  persistence, auth-state routing (v0.2.0)
- **Hearings** — create/edit hearings with one-or-more case numbers per
  hearing, duplicate case-number detection, soft delete (v0.3.0–v0.3.3)
- **Calendar** — Month/Week/Day views, read-only, deep-links into
  Hearings for editing (v0.4.0)
- **Dashboard** — stat cards, Today's Hearings Timeline with live
  Now/Next highlighting, Quick Actions (v0.7.0–v0.8.2)
- **Global Search** — live client-side search across case number,
  parties, charge, date, and status (v0.7.0)
- **Word (DOCX) Export** — Court Calendar export in 4 modes (This
  Hearing/Date/Week/Month), matching the branch's real reference
  document (v0.6.0–v0.6.3)
- **Reports & CSV Export** — date-scoped reports, Status and Hearing
  Type breakdowns, CSV export (v0.9.1, with v0.9.4 adding the "Include
  Archived" option)
- **Activity Log** — an audit trail of every significant action, with
  category filtering (v0.9.0)
- **Role-Based Access Control** — four built-in roles (Administrator,
  Branch Clerk, Encoder, Read Only), enforced in both the UI and
  Firestore Security Rules (v0.9.2)
- **Archive & Case Lifecycle Management** — a restorable soft-archive
  state, fully separate from delete, excluded from active views by
  default (v0.9.3)
- **Backup & Restore** — full-system JSON export/import for disaster
  recovery and cross-project migration, Administrator-only (v0.9.4)
- **Hardening & QA** — a full regression audit, Firestore listener/
  security review, performance pass, and code cleanup (v0.9.5)
- **UI Polish & Accessibility** — visual consistency pass across every
  page, keyboard navigation, focus-visible states, dialog semantics,
  cache-busting (v0.9.6, v0.9.8)
- **Final Acceptance Testing** — two real defects found and fixed
  during release-readiness QA: a Backup & Restore file-picker race
  condition, and a restore-progress-bar miscalculation (v0.9.7)
- **Production Readiness Review** — favicon, custom 404 page, visible
  version indicator, and flagged (unresolved) deployment items: pinning
  `lucide@latest` and confirming the `CNAME` domain (v0.9.9)

**This release**
- `VERSION` → `1.0.0`
- Visible version indicator in the footer (8 pages) updated to `v1.0.0`
- Cache-busting `?v=` query strings (all 11 HTML pages, `404.html`, all
  23 files under `js/`) updated to `1.0.0`
- README.md's introduction, feature list, deployment notes, and roadmap
  updated to reflect a production-ready v1.0.0 (see README for detail)
- New `RELEASE_v1.0.0.md` — the formal release document (introduction,
  highlights, major features, technology stack, architecture summary,
  roadmap, acknowledgements)

**Carried over from v0.9.9, still unresolved — see README's Deployment
Checklist:**
- `https://unpkg.com/lucide@latest` is not version-pinned. Recommended
  before wide production use; not pinned automatically since this
  environment has no outbound network access to confirm a specific
  version number resolves correctly.
- `CNAME` contains a domain (`ourmoment.cc`) that doesn't obviously
  match this project. Needs confirmation from whoever controls the
  actual deployment before the first public DNS cutover.

## [0.9.9] — Final Production Readiness Review (pre-v1.0.0)

A production-polish review pass: no new features, no Firestore/RBAC/
schema changes, no redesign. Three small, safe, isolated gaps were
found and fixed; two supply-chain/deployment risks were found and are
flagged for the person deploying this to decide on, rather than fixed
blindly (see "Flagged, not changed" below for why).

**Fixed**
- **Missing favicon** — every page showed the browser's generic default
  tab icon. Added a simple on-brand favicon (a scales-of-justice glyph
  in the app's own `--ink`/`--brass` colors) as an inline SVG data URI —
  no new binary asset file, no external request, no font-glyph
  dependency (pure SVG shapes, so it renders identically everywhere).
  Added identically to all 11 HTML pages plus the new `404.html` below.
- **Missing custom 404 page** — GitHub Pages serves its own generic,
  unbranded 404 for any unmatched URL by default. Added `404.html` at
  the repository root (where GitHub Pages looks for it), reusing the
  existing `.login-shell`/`.wrap-narrow`/`.card` layout and copy tone
  verbatim from `login.html` — no new CSS, no new JS, just a "Page Not
  Found" message and a link back to `index.html` (which already handles
  routing to Login or Home based on auth state).
- **No visible version indicator** — the release version existed only
  in the invisible `?v=` cache-busting query string, with no way for a
  Clerk or Administrator to see which version they're running (useful
  for support/troubleshooting). Added `&middot; v0.9.9` to the existing
  footer text ("Created by Jordan Panganiban") on all 8 pages that
  already have one — no new element, no layout change.

**Flagged, not changed — needs a decision from whoever deploys this:**
- **`https://unpkg.com/lucide@latest`** (used on 8 pages) is not
  version-pinned, unlike `docx@8.0.4` on the pages that use it. This
  works fine today, but means every page load fetches whatever Lucide's
  *current* latest release happens to be at that moment — if a future
  Lucide release ever renames/removes an icon this app uses (`scale`,
  `gavel`, `archive`, `hard-drive`, etc.) or changes its script's global
  API, every page using icons could break with zero code change on this
  project's side, at an unpredictable time. **Recommended fix:** pin to
  a specific version, e.g. `https://unpkg.com/lucide@<version>`, the
  same way `docx@8.0.4` already is. Not changed in this pass because
  this environment has no outbound network access to confirm which
  version number is actually current and that it resolves correctly —
  pinning to an unverified version number risks trading a low-probability
  future break for a guaranteed one today. Whoever deploys next should
  pin this to whatever Lucide version they've actually tested against.
- **`CNAME` contains `ourmoment.cc`** — this doesn't read as a
  court-related domain name, and doesn't match anything else in this
  project (branding, contact info, etc.). This may be a leftover from
  an unrelated template/starting point rather than a domain actually
  intended for this deployment. **Not changed** — only whoever owns the
  actual deployment can confirm whether this is correct, a placeholder,
  or a mistake; guessing wrong here (removing a legitimately-owned
  domain, or leaving a wrong one in place) is worse than leaving it for
  a human decision.

**Reviewed, already implemented — explicitly acknowledged, not
re-fixed:** loading indicators, empty states, confirmation dialogs
(Archive/Restore), success/error feedback (form-error regions, backup
status/validation panels), accessibility labels (from v0.9.5/v0.9.6),
keyboard accessibility, hover/focus states, browser tab titles (all 11
pages have distinct, correctly-formatted titles), internal navigation,
cache-busting consistency, and Firestore index documentation (README's
Firestore Rules section already notes the single-field index
sufficiency) were all reviewed and found already in place — see the
project's production-readiness report for the itemized checklist.

## [0.9.8] — Final UI/CSS Polish Pass

CSS-only pass across all 9 pages. No JavaScript logic changed, no
Firestore/RBAC/schema changes, no layout redesign, no new features —
confirmed via checksum: `css/styles.css`, `VERSION`, `CHANGELOG.md`, and
the cache-busting version string in every HTML/JS file are the only
things that differ from v0.9.7; every JS file's actual logic is
byte-identical once that version string is stripped back out.

**Fixed**
- `.cal-month-entry` (Calendar Month view's event chip) used a hardcoded
  `border-radius: 4px`, while every other chip/badge in the app —
  including `.cal-week-entry`, the visually-equivalent chip in Week
  view — uses the `var(--radius-sm)` token (6px). Now consistent.

**CSS cleanup — duplication removed (8 rule blocks consolidated, CSS
brace count 310 → 302):**
- The identical 3-line focus treatment (`outline: none; border-color:
  var(--brass); box-shadow: 0 0 0 3px rgba(169, 128, 46, 0.15);`) was
  repeated verbatim across 6 separate rules (`.field input/select/
  textarea`, `.hearings-search input`, `.activity-search input`,
  `.activity-filter select`, `.report-filter select`/`input[type="date"]`,
  `.role-select`). Consolidated into one shared rule with a combined
  selector list.
- `.hearings-search input` and `.activity-search input` were
  byte-identical (9 properties each) — the file even had a comment
  acknowledging this ("same input treatment as .hearings-search").
  Consolidated into one rule; the two wrapper classes stay separate
  since their layout genuinely differs (flex item vs. standalone block).
- `.activity-filter select`, `.report-filter select`/`input[type="date"]`,
  and `.role-select` shared an identical 8-property base style.
  Consolidated into one rule.
- A systematic re-scan for duplicate multi-property rule blocks after
  these merges found none remaining.

**Reviewed, already consistent — no change needed:** table header/row
height, hover color, and empty/loading-state appearance across
Hearings/Reports/Archive/Activity/Users (all reuse the single
`.data-table` class with no page-specific overrides, so consistency is
structural, not coincidental); card padding/radius/shadow/title spacing;
button height/padding/icon-spacing/hover/focus/disabled states (disabled
states were already fixed in v0.9.6); navigation active/hover states and
icon alignment; the Login page's visual match to the rest of the app;
focus-visible coverage (every place `outline: none` is used pairs it
with a visible replacement — none found that silently remove focus
indication); responsive spacing for Archived Hearings and Backup &
Restore (both inherit existing fluid layout classes, reviewed and
unchanged since v0.9.5/v0.9.6). One micro-spacing token gap was
identified and deliberately left alone (`.cal-month-entries`/`.cal-*`
grid gaps below the `--space-1` token floor are intentional hairline/
tight-grouping values, not part of the section/card spacing scale).

**Performance:** this pass reduced CSS size (8 fewer rule blocks) rather
than increasing it — no new selectors, classes, or custom properties
were introduced.

## [0.9.7] — Final Acceptance Testing Patch (pre-v1.0.0)

A QA-only pass: no new features, no schema changes, no UI/architecture
changes. Two real defects were found during release-readiness review
and fixed with the smallest possible change; nothing else in the
project was touched (confirmed via checksum — only the two files below
differ from v0.9.6).

**Fixed**
- `js/backup.js` — a real race condition in Backup & Restore's file
  picker: selecting a backup file starts an async `FileReader` read;
  selecting a *different* file before the first read finishes started a
  second read without invalidating the first. Whichever read happened
  to finish last "won" and silently became `pendingBackup` — which could
  be the *first*, now-stale file, not the one the file input currently
  shows selected. An Administrator could end up restoring from an
  unintended file without any indication anything was wrong. Fixed with
  a selection-generation counter: each file-input `change` event
  increments a token, and a `FileReader` callback bails out if a newer
  selection has since superseded it.
- `js/backup-data.js` — `restoreFromBackup()`'s progress bar could
  permanently under-report and never reach 100%, even on a fully
  successful restore. `grandTotal` counts every record in the backup
  file, but `grandProcessed` previously only advanced for records that
  actually went through a write batch — so malformed records (any
  collection), already-existing entries skipped under `activityLogs`'
  "create-missing" policy, and records under an unrecognized collection
  key were all counted toward the total but never toward progress.  In
  practice this reliably happens on **any restore into an
  already-populated system** (the "recovering from accidental data
  loss" use case explicitly listed for this feature) — its `activityLogs`
  correctly skips every already-existing entry, and this bug meant the
  progress bar would visibly stall short of 100% every time. Fixed so
  every record is now accounted for exactly once: skipped records
  advance the counter immediately (since they're resolved without a
  write), written/failed ones advance it via the existing per-chunk
  logic.

**Cache-busting version bump:** because v0.9.6 tied asset URLs to
`VERSION` specifically so that a code change reaches previously-visited
browsers, shipping the fix above required bumping every `?v=` reference
from `0.9.6` to `0.9.7` (all 11 HTML files + all 23 files under `js/`) —
otherwise a browser that had already cached v0.9.6's `js/backup.js`
could keep serving the pre-fix version indefinitely. No other content
changed in those files; confirmed via diff that stripping the version
string back out reproduces v0.9.6 byte-for-byte in every file except
the two listed above.

**Reviewed, no defect found — every other module:** Authentication,
Dashboard, Today's Timeline, Hearings (including case-row save/delete
diffing), Calendar (including the Day View case-fetch cache), Reports
(including custom date-range input and the Include Archived checkbox),
Activity Log, Archive, Users (including the self-role-lock guard), RBAC,
Search, Word Export, CSV Export, and Navigation were all reviewed for
logic bugs, null/undefined access, race conditions, permission
mistakes, and broken links. See the project's QA report for the full
list of what was checked, including two narrow non-issues noted but
deliberately not changed (an extremely-low-impact duplicate-fetch edge
case in Calendar's Day View, and a missing but harmless input-order
validation on Reports' custom end-date field).

## [0.9.6] — UI Polish & Visual Consistency

Final milestone before v1.0.0. Not a redesign, not a feature milestone —
a visual polish, consistency, and cache-busting pass across all 9 pages
(Login, Home, Hearings, Calendar, Reports, Activity Log, Archived
Hearings, Users, Backup & Restore). No Firestore schema changes, no new
collections, no business-logic or RBAC changes, no layout redesigns.

**Visual consistency audit:** every page was compared against every
other for cards, buttons, forms, tables, typography, icons, and color
tokens. The codebase's existing token system (`var(--space-N)`,
`var(--text-N)`, shared `.btn-primary`/`.btn-secondary`/`.btn-small`,
`.card`, `.data-table`, `.empty-row`, the `eyebrow`/`h1`/`sub` header
pattern) turned out to already be applied consistently almost
everywhere — three concrete inconsistencies were found and fixed:

**Fixed**
- `backup.html` — "Download Backup" and "Restore" used bare
  `.btn-primary` (which is `width: 100%`, appropriate for Login's narrow
  card), so both rendered as full-width buttons spanning the entire
  card — the only two buttons in the app styled that way outside of
  Login. Every other standalone primary button (Add Hearing, Edit/
  Restore This Hearing) uses `.btn-primary.btn-inline` for a normal
  content-sized button; these two now match.
- `reports.html` — the Hearing Report table's initial "Loading…" row was
  missing a `colspan`, unlike every other table's loading/empty row in
  the app (which all span their full column count). Added
  `colspan="7"` to match.
- `css/styles.css` — disabled-state styling (`opacity: 0.55; cursor:
  not-allowed;`) previously existed only for `.btn-primary`. Several
  disabled buttons across the app use `.btn-secondary`
  (`exportWordBtn`) or `.btn-small` (various Backup & Restore buttons)
  and had no visual indication of being disabled at all. Extended the
  same rule to all three button classes.

**Reviewed, already consistent — no change needed:** card padding/
spacing/radius/shadows across every page; the `eyebrow`/`h1`/`sub`
header pattern (identical on all 9 pages); table header capitalization
and column labeling (Archived Hearings correctly extends Hearings'
exact column set); empty-state and loading-state wording (all reuse
`.empty-row`); keyboard navigation, focus-visible outlines, and dialog
`role`/`aria-*` attributes (all addressed in v0.9.5, reused unchanged
here); responsive behavior for the two newest pages, Archived Hearings
and Backup & Restore (both reuse existing fluid layout classes rather
than introducing page-specific ones, so they already inherit the nav/
table responsive rules tuned in earlier milestones).

**Cache busting (new in this milestone):** every internal asset
reference — `css/styles.css` in all 11 HTML files, each page's own
`<script type="module">` entry point, and every local `import ... from
"./*.js"` statement across all 23 JS files — now carries a `?v=0.9.6`
query string tied to the current `VERSION`. This is a static, no-build-
step approach (consistent with the rest of this project's
architecture): every internal module URL changes on every release,
forcing browsers to fetch fresh copies of the whole dependency graph
instead of serving a stale cached file from before the last deploy —
addresses the browser-caching issue observed after previous releases.
Every file that imports a shared singleton module (e.g.
`firebase-init.js`, used by 8+ files for the shared `auth`/`db`
instances) uses the identical version suffix, so the module still
resolves to one single instance across the whole app — no duplicate
Firebase app instances were introduced. **Process for future releases:**
bump `VERSION`, then update the `?v=` suffix to match everywhere it
appears (a single find-and-replace across `*.html` and `js/*.js` is
sufficient — see README's Deployment Checklist, updated with this step).

**Verification:** confirmed via diff against the v0.9.5 baseline that
32 files changed *only* by the addition of the `?v=0.9.6` query string
(zero other bytes differ), 3 files also received the visual fixes above,
and 9 files are fully untouched.

## [0.9.5] — Hardening, QA & Release Preparation

Feature freeze. No new CRUD functionality, no Firestore schema changes,
no new collections, no redesign. A full regression audit, Firestore
listener review, security rules review, responsive/accessibility review,
performance review, and code cleanup pass, in preparation for v1.0.0.
Every defect found was fixed with the smallest possible change while
preserving the established architecture.

**Regression audit:** every module — Authentication, Dashboard,
Timeline, Hearings, Calendar, Quick View, Reports, Activity Log,
Archive, Backup & Restore, Word Export, CSV Export, RBAC, Search,
Navigation — was traced end to end. No regressions found.

**Firestore review:** confirmed exactly one live listener per data need,
across every page controller (`grep`-verified: no page subscribes twice
to the same collection). No duplicated queries. `calendar-data.js`'s and
`reports.js`'s active/archived filtering both already routed through the
same centralized `isActiveHearing()` (v0.9.3); no change needed there.
Range queries still only need Firestore's automatic single-field index.
No unnecessary reads found.

**Security review:** every Firestore rule was checked line-by-line
against `js/permissions.js`'s role matrix — `hearings` (create/update,
including the soft-delete and archive guards), `hearingCases`,
`activityLogs` (including its intentional immutability), `users`
(including the v0.9.4 Administrator-create branch), and `systemStatus`.
All match the RBAC matrix; no unauthorized-write paths found; no rule
changes required this milestone.

**Fixed**
- `js/reports-data.js` — removed three confirmed-dead functions
  (`computeDailyReport`, `computeWeeklyReport`, `computeMonthlyReport`):
  defined in an earlier Reports iteration, superseded by the current
  scope-filter approach, and never called from `reports.js` or anywhere
  else. `groupByDay`, `getHearingsForYear`, and every other helper in the
  file remain — all still in active use.
- `js/reports.js` — `render()` was calling `reportHearings()` (the
  active/archived filter) twice per render (once inside `renderSummary()`,
  once inside `dateScopedHearings()`). Both functions now accept an
  optional pre-filtered array; `render()` computes it once and passes it
  to both. The CSV-export call site is unaffected (still computes its own
  when called directly).
- `js/backup-data.js` — `exportBackup()` read its 5 collections one at a
  time with sequential `await`s; they have no ordering dependency, so
  they now run concurrently via `Promise.all()`. Same data, same shape,
  faster on real network latency.
- `css/styles.css` — removed 3 confirmed-dead rules (`.auth-btn`, `.field
  .hint`, `.home-nav` + its 2 descendant rules) and the now-orphaned
  `[data-action="delete"]::before` icon rule and `--icon-trash` custom
  property (both left over from before "Delete" was replaced by
  "Archive" in v0.9.3 — nothing has used `data-action="delete"` since).
- **Accessibility:** Hearings' and Archived Hearings' table rows were
  mouse-only (click-to-preview with no keyboard path) — Home's Timeline
  rows already solved this exact problem in v0.8.2 (tabindex, role, Enter/
  Space handling) but the fix was never extended to these two tables.
  Applied the same technique to both, plus a matching `:focus-visible`
  outline. Added `role="dialog"`/`aria-modal`/`aria-label` to both Quick
  View modals (Hearings' and Archived Hearings') — previously not
  identified as dialogs to assistive tech. Added an `aria-label` to each
  row's role `<select>` on the Users page (previously relied only on
  table position for its accessible name). Added a `<label>` for
  Backup's file input (previously had none) and `role="status"` to
  Backup & Restore's dynamic status/validation/result regions so they're
  announced when populated.

**Reviewed, no change needed:** responsive layout for every page at
tablet/phone widths (the two newest pages, Archived Hearings and Backup
& Restore, both reuse existing fluid `.card`/`.wrap-wide`/`.data-table`/
`.hearings-search` patterns rather than introducing new ones, so they
already inherit the nav/table responsive behavior tuned in earlier
milestones); color contrast (unchanged design-system tokens); tab order
(no non-`0` `tabindex` values anywhere in the app).

**Identified, deliberately not changed:** `hearingsToCsvRows()` and the
`casesForHearing()`-style lookup used throughout the app filter the full
cases array per hearing (O(n·m)) rather than pre-grouping by hearing ID
once. This is a pre-existing pattern used consistently across
`hearings.js`, `archived.js`, and `reports-data.js` — changing it would
mean touching the shared data-access pattern in multiple files, which is
a redesign, not a fix, and out of scope for a minimal-change hardening
pass. At this system's realistic scale (a single RTC branch's docket)
it is not expected to be a real bottleneck; noted for a future
performance-focused milestone if data volume ever grows enough to
matter.

**Documentation:** added Deployment Checklist, Production Checklist,
Backup Procedure, Restore Procedure, Recommended Browser Support, and
Known Limitations to README.md (see Milestone 15 below).

## [0.9.4] — Backup & Restore

Introduces a system-wide Backup & Restore module for Administrators —
manual backups, disaster recovery, migration between Firebase projects,
and recovering from accidental data loss. No new Firestore collection;
no schema changes.

**Added**
- `js/backup-data.js` — the sole Firestore access layer for this
  milestone (no UI). `exportBackup()` reads `hearings`, `hearingCases`,
  `activityLogs`, `users`, and `systemStatus` (this app's real
  system-level collection — there is no `systemConfig` collection, see
  README's Milestone 14 for why that name is mapped onto `systemStatus`
  instead of inventing a new one) and serializes Firestore Timestamp
  fields to a small recoverable `{ __type: "timestamp", seconds,
  nanoseconds }` shape so they can be reconstructed as real Timestamps
  on restore. `validateBackupFile()` is pure (no Firestore) and checks a
  selected file's shape before anything is written.
  `restoreFromBackup(backup, onProgress)` writes in 400-document
  `writeBatch` chunks, yielding to the browser between chunks so a large
  restore never freezes the tab, and reports progress via callback.
  Per-collection restore policy: `hearings`/`hearingCases`/`users` are
  "upsert" (update existing, create missing, never delete);
  `activityLogs` is "create-missing" (only writes entries that don't
  already exist at the destination, since its own Firestore rule is
  intentionally `update: false` — an immutable audit trail that restore
  must not fight); `systemStatus` is "skip" (exported for reference only,
  never restored — its rule is `write: false` and it holds no real
  configuration). Malformed records (missing/invalid `id`, or not an
  object) are filtered out before batching, so one bad record can never
  take an otherwise-good batch down with it; a batch whose `commit()`
  fails (a recoverable error) is recorded as failed and the restore
  continues with the next batch/collection.
- `js/backup.js` — the page controller (Administrator only). Triggers
  the backup download (own local `downloadBlob()`, same convention as
  `docx-export.js`/`reports.js` each keeping their own copy rather than
  sharing one), handles file selection + validation display, the
  restore confirmation dialog (states the exact update/create/
  never-delete behavior and per-collection counts before anything is
  written), the progress bar, and the post-restore summary. No Firestore
  logic of any kind lives in this file.
- `backup.html` — new page, reuses the existing Branch 9 UI shell
  (nav/header/card patterns) exactly as every other page does.
- New "Backup" nav link (`data-permission="backup.manage"`) added to all
  7 existing pages' nav bar, same `data-permission`-hiding mechanism
  already used for Reports/Activity Log/Users/Archived.
- `logActivity()` (unchanged) now also records `Backup Created`,
  `Restore Started`, `Restore Completed`, and `Restore Failed` — reuses
  the exact same helper every other logged action already uses.

**Changed**
- `js/permissions.js` — `PERMISSIONS.BACKUP_MANAGE` (reserved back in
  v0.9.2 specifically for this milestone) is now wired to `backup.html`.
  No role changes: it remains Administrator-only, exactly as v0.9.2's
  permission matrix already documented.

**Firestore Security Rules**
- See README.md, "Firestore Security Rules for RBAC" — the `users`
  collection's `create` rule gained an Administrator branch, allowing
  Administrator to create any user's role document from scratch (not
  just their own). This is required specifically for restoring to a
  brand-new Firebase project during a migration, where the destination
  has no matching `users/{uid}` docs yet. This is the only rules change
  required for this milestone — `hearings`, `hearingCases`,
  `activityLogs`, and `systemStatus` rules are unchanged from v0.9.3
  (deliberately: see `activityLogs`' "create-missing" restore policy
  above for why its restrictive rule did not need to change).

**Recommendation going forward:** this is the last planned feature
milestone before release hardening. v0.9.5 should be used exclusively
for bug fixes, performance improvements, a security rules review,
responsive UI polish, code cleanup, and final regression testing ahead
of v1.0.0 — no new features.

## [0.9.3] — Archive & Case Lifecycle Management

Introduces a proper Archive workflow, completely separate from the
existing soft-delete. Archiving a hearing is a soft state change only —
the document (and its cases) are never touched beyond four new fields,
nothing is ever moved or duplicated, and every archived hearing can be
restored. No new Firestore collection.

**Added**
- `isArchived` / `archivedAt` / `archivedBy` / `archiveReason` fields on
  the existing `hearings` documents — same collection, same document,
  additive fields only. `hearingCases` is untouched by archiving.
- `isActiveHearing(h)` in `js/hearings-data.js` — the ONE centralized
  definition of "is this hearing in active operations" (not soft-deleted
  AND not archived). `subscribeToHearings()` uses it by default so every
  existing caller (Home Dashboard, Today's Timeline, Search, Active
  Hearings, Quick Actions) automatically excludes archived hearings with
  no call-site changes required. `calendar-data.js`'s
  `subscribeToHearingsInRange()` now imports and reuses this same helper
  instead of its own inline `isDeleted` check, fixing a small pre-existing
  duplication in the same pass.
- `archiveHearing(hearingId, reason)` / `restoreHearing(hearingId)` in
  `js/hearings-data.js` — mirror the existing `deleteHearing()`
  soft-state pattern exactly (a `writeBatch` merge, never a document
  delete or move).
- `subscribeToArchivedHearings()` in `js/hearings-data.js` — same
  collection/query shape as `subscribeToHearings()`, opposite filter;
  powers the new Archived Hearings page.
- `archived.html` + `js/archived.js` — new Archived Hearings page
  (Administrator/Branch Clerk only, gated by `PERMISSIONS.ARCHIVE_MANAGE`
  same as the row actions below). Reuses the existing hearings table
  styling and the existing Quick View modal's CSS classes/layout for its
  own read-only View action; no create/edit/delete logic of any kind
  lives here. Restore resets `isArchived` to `false`. Live client-side
  search, same matching fields as Hearings' search.
- "Include Archived" checkbox on Reports (`reports.html`/`js/reports.js`),
  **default OFF**. When on, every report (Hearing Report, Status Report,
  Hearing Type Report, summary cards) and the CSV export include archived
  hearings — reusing the same `isActiveHearing()` filter, applied once in
  a new `reportHearings()` helper that every existing computation already
  routes through. Word export is explicitly unaffected by this checkbox
  and always covers active hearings only, per this milestone's
  requirement that the DOCX generator itself stay untouched.
- New "Archived" nav link (`data-permission="archive.manage"`) added to
  all 6 existing pages' nav bar, same `data-permission`-hiding mechanism
  `nav-auth.js` already uses for Reports/Activity Log/Users.
- `logActivity()` (unchanged) now also records `Archived Hearing` and
  `Restored Hearing` — reuses the exact same helper every other logged
  action already uses. `activity.js`'s existing CRUD category bucket
  grows to include both (was: Create/Edit/Delete Hearing only).

**Changed**
- `js/permissions.js` — `PERMISSIONS.ARCHIVE_MANAGE` (reserved back in
  v0.9.2 specifically for this milestone) is now wired to the Archive/
  Restore row actions and the whole Archived Hearings page. **Bug fix in
  the same pass:** Branch Clerk's permission list was missing
  `ARCHIVE_MANAGE` even though the v0.9.2 permission-matrix table already
  documented Branch Clerk as having Archive/Backup access reserved —
  added, matching Administrator; Encoder and Read Only remain without it,
  per this milestone's RBAC requirement.
- `js/hearings.js` — the "Delete" row action (soft-delete via
  `deleteHearing()`) is replaced with "Archive" (`archiveHearing()`),
  gated by `PERMISSIONS.ARCHIVE_MANAGE` instead of
  `PERMISSIONS.HEARINGS_DELETE`. `deleteHearing()` itself is untouched in
  `hearings-data.js` and remains available to any other code path; this
  milestone only changes what the Hearings page's own row button calls.

**Firestore Security Rules**
- See README.md, "Firestore Security Rules for RBAC" — a
  `canArchiveHearings()` function and an `isArchiveChange()` guard
  (mirroring the existing `isSoftDelete()` guard) were added to the
  `hearings` collection's `update` rule. Deploy the updated rules
  alongside this release; UI hiding alone is never the security boundary.

## [0.9.2] — Role-Based Access Control (RBAC)

Introduces four built-in roles (Administrator, Branch Clerk, Encoder, Read
Only), a centralized permission helper every page now calls, a new
User Management page, and the Firestore Security Rules required to
actually enforce it server-side — not just hide buttons client-side. No
business logic changed: the same save/delete/export functions run
exactly as before, they're just reachable by fewer roles now.

**Added**
- `js/permissions.js` — the one reusable permission helper. Pure logic,
  no Firestore, no DOM: `ROLES`, `PERMISSIONS`, the role→permission
  matrix, and `can(role, permission)`. Every page checks against this
  instead of comparing role strings itself. Also defines
  `PERMISSIONS.ARCHIVE_MANAGE`/`BACKUP_MANAGE` — unused today, reserved
  so the Archive and Backup milestones can call `can()` directly instead
  of adding new permission plumbing.
- `js/users-data.js` — Firestore only, the sole file that reads/writes
  the `users` collection. `getOrCreateUserRole(user)` resolves a
  signed-in user's role, creating their `users/{uid}` document with the
  default role (`branch_clerk`) the first time that account is ever
  seen — there's no separate account-creation step, and no migration: a
  document with no `role` field yet is treated as `branch_clerk` in
  memory without being rewritten. Never throws — a Firestore failure
  here falls back to the default role with a console warning rather
  than blocking sign-in on every page. `subscribeToAllUsers()` powers
  User Management; `updateUserRole()` changes one user's role.
- `js/users.js` + `users.html` — the new User Management page.
  Administrator only: lists every account that has ever signed in
  (sourced from the `users` collection — this app has no Admin SDK
  access and cannot enumerate Firebase Authentication accounts
  directly), shows email and role, and lets an admin change a role via
  a `<select>`. An admin can't change their own role from this screen
  (prevents accidentally locking out the only admin). "Add User" is a
  disabled placeholder — no account creation, matching the milestone
  brief.
- New CSS in `css/styles.css` for the Users role `<select>` — additive
  only, existing design tokens, no existing rule changed.
- `logActivity()` (unchanged) now also records `Change User Role` from
  `users.js` — no new logging architecture, same helper every other
  logged action already uses.

**Changed**
- `js/auth-guard.js` — `requireAuth()` now also resolves the signed-in
  user's role (one Firestore read via `users-data.js`, not a listener)
  and attaches it as `user.role`. This is the exact extension point this
  file's own header comment anticipated back when it was written:
  "pages that already call `requireAuth()` will not need to change" —
  and none of them did, for the auth mechanism itself. Added
  `requirePermission(user, permission, { redirectTo })`: the new
  page-level gate, used by `activity.js`, `reports.js`, and `users.js`
  to redirect away a role that's denied a whole page (as opposed to
  individual buttons within a page the role can otherwise access, which
  stays a per-page concern via `can()`).
- `js/nav-auth.js` — `wireNavAuth()` now hides nav links a role can't
  use, centrally, in the one place every page already calls to wire its
  nav. A link opts in with `data-permission="<permission>"`; links with
  none (Home, Hearings, Calendar) are always shown since every role has
  access to those. This is the single call site for "which nav links
  show" — no page repeats the check itself.
- `home.html`, `hearings.html`, `calendar.html`, `activity.html`,
  `reports.html` — added `data-permission` to the Activity Log and
  Reports links, and a new Users link, all hidden/shown by the change
  above.
- `js/hearings.js` — Add/Edit/Delete are gated at their true
  chokepoints (`openAddForm()`, `openEditForm()`, `handleDelete()`,
  `handleSave()`) rather than scattered across every call site: Calendar
  and Home's deep links, the row buttons, the Quick View's "Edit"
  shortcut, and the `?action=add`/`?openHearing=` URL params all funnel
  through the same few guarded functions. A role without edit
  permission arriving via Calendar's `?openHearing=` link now sees the
  read-only Quick View instead of nothing — Calendar itself needed no
  changes for this. Row-level Edit/Delete buttons, the Add Hearing
  button, the Export Calendar dropdown, and the per-hearing Export to
  Word button are only rendered for roles with the matching permission
  ("do not show actions the user cannot perform"), not just disabled.
- `js/home.js` — the Add Hearing and Export Today's Calendar Quick
  Action buttons are hidden (not just disabled) for roles without the
  matching permission, with a defense-in-depth guard on the export
  handler itself. Also fixes a layout edge case this hiding introduced:
  the mobile 2-column Quick Actions grid used to span a lone leftover
  button full-width via a plain `:last-child` CSS rule, which only
  looked at DOM position — with Export hidden for Read Only, the DOM's
  last child stopped being the last *visible* one, leaving a single
  remaining button (Open Calendar) stuck in column 1 with an empty
  column 2 beside it. `updateQuickActionsLayout()` now computes which
  button is actually last among the visible ones and marks it directly
  (`.quick-action-last-visible` in `css/styles.css`), used only when
  there's an odd number of visible buttons — with exactly two visible
  they already fill one row evenly.
- `js/reports.js` — the whole page now requires `reports.view`
  (Encoder is redirected to Home); Export CSV/Word are hidden — not
  just disabled — for Read Only, which has `reports.view` but not
  `export`.
- `js/activity.js` — the whole page now requires `activityLog.view`
  (Encoder and Read Only are redirected to Home). No change to what's
  logged or how — same `logActivity()`/`subscribeToActivityLogs()` as
  before.

**Roles and the permission matrix, Firestore Security Rules for RBAC
(including an important nuance about how "Delete Hearing" is
implemented), and the full testing checklist are in `README.md`,
"Milestone 12: Role-Based Access Control (RBAC)."**

**Not changed:** Any save/delete/export/report/logging business logic —
every function that used to run for every signed-in user runs exactly
the same way today, just gated to fewer roles. Dashboard/Calendar/
Reports/Activity Log computation, Word Export document generation,
Search, Quick View, responsive layout, and no Firestore schema changes
(one new collection, `users`, with a `role` field — no migration).

**Files confirmed byte-identical to v0.9.1:** `js/activity-data.js`,
`js/calendar-data.js`, `js/calendar.js`, `js/constants.js`,
`js/dashboard-live.js`, `js/dashboard-stats.js`, `js/diagnostics.js`,
`js/docx-export.js`, `js/export-data.js`, `js/firebase-config.js`,
`js/firebase-init.js`, `js/hearings-data.js`, `js/index.js`,
`js/login.js`, `js/reports-data.js`, `index.html`, `login.html`,
`diagnostics.html`, `CNAME`.

## [0.9.1] — Reports & Statistics

A read-only Reports module for the Branch Clerk of Court, built entirely
on hearings/hearingCases data already loaded elsewhere. No CRUD behavior
changes anywhere, no new Firestore listeners, no schema changes.

**Added**
- `js/reports-data.js` — pure computation only (no Firestore, no DOM):
  report calculations, filtering, and statistics. Reuses rather than
  re-implements what already exists: `getHearingsForDate/Week/Month`
  from `export-data.js` (the exact functions every Word export mode
  already uses), `computeDashboardStats()` from `dashboard-stats.js` for
  Active Cases, and `DEFAULT_HEARING_DURATION_MINUTES` from
  `dashboard-live.js` so "Completed" uses the same 30-minute assumption
  the Home dashboard's Timeline already uses instead of a second
  hardcoded number. Adds `getHearingsForYear` and
  `getHearingsForDateRange` (Custom Date Range), status/section
  filtering, day-grouping, the five reports, `computeSummaryStats()`,
  and a pure CSV builder (`buildCsv`/`hearingsToCsvRows`/`CSV_HEADERS`).
- `js/reports.js` — UI only: rendering, filters, and export actions. No
  Firestore logic. Reuses the existing `subscribeToHearings()`/
  `subscribeToCases()` live listeners (no new listener types), and
  reuses `exportCourtCalendarForDate/Week/Month` from `docx-export.js`
  verbatim for the Word export path — no second docx builder.
- `reports.html` — new page, added to the nav on Home, Hearings,
  Calendar, and Activity Log. Reuses the existing dashboard stat-card
  grid, card/table/toolbar styling, and button styles — no new design
  language.
- New CSS in `css/styles.css` for the Reports filter row, export
  actions, section headings, day-group divider rows, and the two-column
  breakdown-report layout — additive only, using only existing design
  tokens, no existing rule changed.

**Reports implemented**
- Daily / Weekly / Monthly Hearing Report — one unified hearing-list view
  whose granularity follows the Range filter: Today (or a single-day
  Custom Range) is a flat list; This Week, This Month, or a multi-day
  Custom Range groups by day.
- Hearing Status Report — counts by the actual `status` value present in
  the data (see Architecture Note below).
- Hearing Type Report — counts by `section` (see Architecture Note
  below).
- Summary cards: Total Hearings, Active Cases, Hearings This Month,
  Hearings This Year, Pending Hearings, Completed Hearings — always
  computed over the full dataset, same "global overview" behavior as the
  Home dashboard's own stat cards, independent of the page's filters.
- Filters: Today / This Week / This Month / Custom Date Range, Status,
  and Hearing Type — all client-side over already-loaded data.
- Export: CSV always reflects every active filter. Word reuses the
  existing per-scope export functions verbatim and is only offered for
  Today/Week/Month with Status and Hearing Type both set to "All" — see
  Architecture Note.
- Both export actions call the existing `logActivity()` helper
  (`js/activity-data.js`, unchanged) — Milestone 8 documented "Reports"
  as a category the Activity Log was explicitly designed to support
  later without redesign; this is that.

**Architecture notes**
- `hearing.status` is a stage/purpose label (e.g. "Pre-Trial
  Conference"), not a lifecycle state — Firestore has no Pending/
  Completed/Postponed/Cancelled field (documented first in
  `dashboard-live.js`, Milestone 8). Rather than invent that vocabulary,
  the Hearing Status Report counts the real status values present in the
  data, and the summary cards' Pending/Completed are derived from
  `hearingDateTime` the same way the Home dashboard's Timeline already
  derives "completed" for today's hearings — just generalized to every
  hearing, not only today's.
- `hearing.hearingType` is free text (e.g. "Cross Examination of
  Prosecution's Witness AAA"); grouping by it verbatim would produce a
  long tail of one-off buckets rather than a report. `hearing.section`
  is the fixed, small set this milestone's Hearing Type Report examples
  actually describe (Arraignment, Trial, Promulgation, Pre-Trial...), so
  the Hearing Type Report groups by section instead.
- Word export is only offered when reusing the existing
  `exportCourtCalendarForDate/Week/Month` functions verbatim would
  produce a document that actually matches what's on screen — i.e. no
  Status/Hearing Type filter narrowing beyond the date scope, since
  those functions re-derive their own date scope internally from the
  full hearings/cases arrays. Rather than write a second docx builder
  that accepts a pre-filtered subset (duplicating `docx-export.js`'s
  internals), CSV — fully under this file's control — handles every
  filter combination, and the Word button is simply disabled when a
  Status/Hearing Type filter is active or the range is Custom.

**Not changed:** Authentication flow, Dashboard/Live Dashboard/Timeline
computation, Search, Calendar, Hearings CRUD, Quick View/Lightbox, Word
Export document generation, Activity Log, responsive layout, and no
Firestore schema or Security Rule changes of any kind — this milestone
reads `hearings`/`hearingCases` only, and writes only to the existing
`activityLogs` collection via the unchanged `logActivity()` helper.

**Files confirmed byte-identical to v0.9.0:** `js/activity-data.js`,
`js/activity.js`, `js/auth-guard.js`, `js/calendar-data.js`,
`js/calendar.js`, `js/constants.js`, `js/dashboard-live.js`,
`js/dashboard-stats.js`, `js/diagnostics.js`, `js/docx-export.js`,
`js/export-data.js`, `js/firebase-config.js`, `js/firebase-init.js`,
`js/hearings-data.js`, `js/hearings.js`, `js/home.js`, `js/index.js`,
`js/login.js`, `js/nav-auth.js`, `index.html`, `login.html`,
`diagnostics.html`, `CNAME`. (`activity.html`, `calendar.html`,
`hearings.html`, `home.html`, and `css/styles.css` changed only to add
the Reports nav link / its additive styling — see above.)

## [0.9.0] — Audit Trail & Activity Log

Adds accountability logging across the system. Not a redesign, not a
Firestore migration, not a schema rewrite — every feature working in
v0.8.2 continues to work exactly as before. See the Verification
Checklist below for what was re-confirmed unchanged.

**Added**
- New Firestore collection: `activityLogs` (only new collection —
  `hearings`, `hearingCases`, `systemConfig`, and `users` are untouched,
  no migration, no schema changes to any of them). Documents store
  lightweight audit fields only (`timestamp`, `userEmail`, `action`,
  `module`, `entityId`, `entityType`, `description`, and optional
  `oldValue`/`newValue`) — never a full hearing object.
- `js/activity-data.js` — the only file that reads or writes
  `activityLogs`. Exports `logActivity(...)` (fire-and-forget; never
  throws, so a logging failure never blocks or interrupts the action it
  describes — a console warning is printed instead) and
  `subscribeToActivityLogs()` (a live listener capped at the 500 most
  recent entries, so the feed stays cheap regardless of how long the
  court has been using the system). No UI code in this file, matching
  the existing hearings-data.js/calendar-data.js split.
- `js/activity.js` — Activity Log page controller: renders the live feed
  newest-first, live client-side search (user/action/description,
  case-insensitive), and a category filter (All/CRUD/Export/
  Authentication/Other). No Firestore logic in this file.
- `activity.html` — new page, added to the nav on Home, Hearings, and
  Calendar. Reuses the existing card/table/toolbar/search styling —
  no new design language.
- New CSS in `css/styles.css` for the Activity Log's search box and
  filter dropdown, using only existing design tokens — additive only,
  no existing rule changed.

**Changed (logging calls only — no behavior changes)**
- `js/login.js` — logs `Login` after a successful sign-in, before the
  redirect to Home.
- `js/nav-auth.js` — logs `Logout` (captured while the user is still
  known, since `auth.currentUser` clears once `signOut()` resolves)
  before signing out. This is the single shared Logout handler already
  used by Home, Hearings, and Calendar, so no logging code needed to be
  duplicated across those three pages.
- `js/hearings.js` — logs `Create Hearing` / `Edit Hearing` after a
  successful save, `Delete Hearing` after a successful soft-delete,
  `Export Hearing Order` after the per-hearing Word export, and
  `Export Selected Date's Calendar` / `Export Weekly Calendar` /
  `Export Monthly Calendar` after each Court Calendar export mode. The
  three Court Calendar modes share one small `onSuccess` hook added to
  the existing `withExportButton()` wrapper, so the logging call itself
  isn't duplicated three times.
- `js/home.js` — logs `Export Today's Calendar` after the dashboard
  Quick Action's export succeeds.
- No changes to `js/docx-export.js`. See "Architecture note" below.

**Architecture note**
- `docx-export.js` is documented as strictly isolated from Firestore and
  auth. Rather than break that isolation to log exports from inside it,
  every export log call was added at the existing call sites in
  `hearings.js`/`home.js` — the same places that already have the
  hearing data and signed-in user needed for a useful log description.
  `docx-export.js` itself is unchanged.

**Not changed:** Authentication flow, Dashboard/Live Dashboard/Timeline
computation, Search, Calendar, Hearings CRUD business logic, Quick
View/Lightbox, Word Export document generation, responsive layout,
Firestore schema for `hearings`/`hearingCases`/`systemConfig`/`users`,
and no existing Security Rule was modified (a new rule is required for
the new `activityLogs` collection — see `README.md`).

**Files confirmed byte-identical:** `js/auth-guard.js`,
`js/calendar-data.js`, `js/calendar.js`, `js/constants.js`,
`js/dashboard-live.js`, `js/dashboard-stats.js`, `js/diagnostics.js`,
`js/docx-export.js`, `js/export-data.js`, `js/firebase-config.js`,
`js/firebase-init.js`, `js/hearings-data.js`, `js/index.js`,
`index.html`, `login.html`, `diagnostics.html`, `CNAME`.

## [0.8.2] — Responsive Dashboard & Productivity Polish

UI/UX milestone only — no Firestore, auth, CRUD, Calendar, Word Export,
Search, dashboard-computation, or listener changes.

**Changed**
- **New tablet breakpoint at ≤1024px** (previously the only breakpoint
  was ≤768px). Home's two-column layout (`.dashboard-main-row`) now
  collapses to one column starting at 1024px instead of 768px, so
  Today's Hearings still reads clearly on a tablet, not just a phone —
  it's still first in DOM order, so it still renders before the sidebar
  cards. Nav wrap-safety (wrapping, brand truncation, email ellipsis,
  logout staying reachable) was promoted from the ≤768px tier to this
  new ≤1024px tier, since at the old threshold a nav with a full-length
  brand + 3 links + email + logout could overflow horizontally on
  tablet-width screens between 769–1024px. The ≤768px tier now only
  holds its remaining phone-specific deltas (smaller nav text/padding,
  34vw email truncation, 2x2 stat grid, the sticky-header workaround).
  **Desktop (>1024px) is completely unchanged** — none of this applies
  above 1024px.
- **Quick Actions is now a 2-column grid on phones** (≤768px) instead of
  a single stacked column, with the odd button (Export) spanning the
  full width of its own row; desktop/tablet keep the existing single-row
  layout. Buttons also gained `height: auto` + wrapping on phones so a
  longer label (e.g. "Export Today's Calendar") can't get clipped in a
  narrow column. Same buttons, same click handlers — no logic touched.
- **Now Hearing / Next Hearing / Today's Hearings shrink a bit further
  when empty.** `.session-card--compact`'s padding was tightened again,
  and a new `.dashboard-timeline-card--empty` modifier (toggled by
  `home.js` alongside the existing empty-state check — no new
  computation, just a class toggle) trims the Timeline card's own
  padding when there's nothing to show. No fixed heights were
  introduced anywhere; cards still grow to fit real content exactly as
  before.
- **Timeline visual polish**: more vertical spacing and a larger
  clickable area per row (bigger padding, no change to which element is
  clickable or where it navigates), a thicker higher-contrast connector
  line (`var(--line-strong)`, up from `var(--line)`), slightly larger
  status badges, a smoother hover transition, and the current hearing
  now gets an inset accent border (`var(--green)`) plus a larger dot for
  a clearer highlight. All existing color tokens — no new ones.
- **Keyboard accessibility**: Timeline rows are now focusable
  (`tabindex="0"`, `role="button"`, a descriptive `aria-label`) and
  Enter/Space trigger the same navigation a click does — previously
  they were mouse-only. Visible `:focus-visible` outlines added to
  buttons (`.btn-primary`/`.btn-secondary`/`.btn-small`), nav links, the
  Logout button, and Timeline rows, all reusing existing
  `--brass`/`--brass-dark` tokens. Tab order is unchanged (elements were
  simply made reachable at their existing DOM position, not reordered).
  Smoother hover transitions added to nav links and the Logout button to
  match the buttons' existing transition.

**Not changed:** Firestore schema, security rules, CRUD logic,
authentication flow, Calendar (page, `calendar.js`, or `calendar-data.js`),
Word Export document builder, Court Calendar Export logic, Search, the
Quick View/Lightbox implementation in `hearings.js`, or any function in
`dashboard-stats.js`/`dashboard-live.js`. No new Firestore listeners.
Confirmed by checksum: `hearings-data.js`, `calendar-data.js`,
`calendar.js`, `calendar.html`, `hearings.html`, `hearings.js`,
`nav-auth.js`, `firebase-init.js`, `firebase-config.js`, `auth-guard.js`,
`diagnostics.js`, `diagnostics.html`, `login.js`, `login.html`, `index.js`,
`index.html`, `docx-export.js`, `export-data.js`, `constants.js`,
`dashboard-stats.js`, and `dashboard-live.js` are all byte-identical to
v0.8.1 — only `home.html`, `js/home.js`, and `css/styles.css` were
modified; no files were added.

## [0.8.1] — Dashboard UX Polish

UI/UX refinement only — no Firestore, auth, CRUD, Calendar, Word Export,
Search, Quick View implementation, or dashboard computation changes.

**Changed**
- **Today's Hearings is now the dashboard's visual centerpiece.** `home.html`
  is restructured into a wide main column (the Timeline) alongside a
  narrower sidebar (Now Hearing, Next Hearing, Today's Summary, Quick
  Actions) — `.dashboard-main-row` / `.dashboard-main-col` /
  `.dashboard-side-col`, replacing v0.8.0's equal-width
  `.dashboard-live-row`. The Timeline's heading is larger, and each row
  gets more padding/spacing for easier scanning. Click-to-Lightbox
  behavior (`?previewHearing=<id>` → the existing Quick View modal) is
  completely unchanged.
- **Now Hearing and Next Hearing are now two independent cards** instead
  of one card that toggled between them. A Clerk mid-hearing can now
  still see what's coming up next. Each has its own compact empty state
  (`.session-card--compact`, less padding) so an idle card doesn't
  reserve the same space as one showing real hearing details: "No active
  hearing." for Now Hearing, "No upcoming hearings today." for Next
  Hearing (previously both cases just showed "No active hearing.").
  Still built from the exact same `getCurrentHearing()` /
  `getNextUpcomingHearing()` / `minutesUntil()` in `dashboard-live.js` —
  that file is untouched.
- **Today's Summary redesigned as a horizontal row** (Scheduled /
  Completed / Remaining side by side) instead of v0.8.0's stacked rows —
  same `getTodaysSummary()`, same `.summary-value`/`.summary-label`
  typography, just a `.summary-columns` grid instead of `.summary-row`
  stack.
- **More professional empty state** for an empty Timeline: "No hearings
  scheduled for today. Use Add Hearing or open the Calendar to schedule
  one." replaces v0.8.0's "Enjoy the quiet day." New `.timeline-empty`
  class (kept separate from the shared `.empty-row`, which other pages'
  JS depends on, so it was safe to leave completely alone).
- **Icons added to section headings** (Today's Hearings, Quick Actions,
  Now Hearing, Next Hearing, Today's Summary) using Lucide, the same
  library already loaded on every page — no new icon library, no new
  colors.
- Timeline status badges (Now/Next/Completed/Upcoming) get slightly more
  breathing room to match the timeline's larger scale; same
  `--green`/`--blue`/`--gray-bg`/`--amber` tokens as v0.8.0, no new color
  variables.
- Mobile (≤768px): the new `.dashboard-main-row` and `.summary-columns`
  stack to one column, same pattern as v0.8.0's now-removed
  `.dashboard-live-row` override. No broader responsive redesign, as
  requested — that's planned for after v1.0.

**Not changed:** Firestore schema, security rules, CRUD logic,
authentication flow, Calendar (page, `calendar.js`, or `calendar-data.js`),
Word Export document builder, Court Calendar Export logic, Search, the
Quick View/Lightbox implementation in `hearings.js`, or any function in
`dashboard-stats.js`/`dashboard-live.js`. Confirmed by checksum:
`hearings-data.js`, `calendar-data.js`, `calendar.js`, `calendar.html`,
`hearings.html`, `hearings.js`, `nav-auth.js`, `firebase-init.js`,
`firebase-config.js`, `auth-guard.js`, `diagnostics.js`, `diagnostics.html`,
`login.js`, `login.html`, `index.js`, `index.html`, `docx-export.js`,
`export-data.js`, `constants.js`, `dashboard-stats.js`, and
`dashboard-live.js` are all byte-identical to v0.8.0 — only `home.html`,
`js/home.js`, and `css/styles.css` were modified; no files were added.

## [0.8.0] — Branch Clerk Productivity Dashboard

**Added**
- **Today's Hearings Timeline** (replaces v0.7.2's simple list): a vertical
  timeline on `home.html` with a connecting rail/dot per hearing, a status
  badge (Now / Next / Completed / Upcoming), and a highlighted background
  for the current and next hearings. Still sorted chronologically, still
  today's hearings only, still built entirely from the same already-loaded
  `hearings` array via the existing `getTodaysHearingsSorted()` — zero new
  Firestore reads. Shows "No hearings scheduled today. Enjoy the quiet
  day." when empty.
- **Current Session card**: shows the hearing considered "in progress"
  right now, or "No active hearing." if none is. **Next Hearing card**:
  shown instead whenever there's no active hearing, with a live "Starts in
  N minutes" countdown. Both are pure client-side computation, re-rendered
  on a 30-second timer so they stay accurate as time passes with no new
  Firestore activity.
- **Today's Summary card**: Scheduled / Completed / Remaining counts for
  today, computed the same way.
- **Quick Actions**: Add Hearing, Open Calendar, and Export Today's
  Calendar buttons. Add Hearing and Export Today's Calendar reuse existing
  logic unchanged (see below); Open Calendar is a plain link — Calendar
  itself is completely untouched.
- New `js/dashboard-live.js` — pure computation only (no Firestore/DOM),
  alongside `dashboard-stats.js` rather than inside it: `getCurrentHearing`,
  `getNextUpcomingHearing`, `getTodaysSummary`, `minutesUntil`, and
  `annotateTimelineStatuses`. Since the hearings schema has no duration or
  completion field ("status" is actually the hearing's stage, e.g.
  "Pre-Trial Conference," not a workflow state), "current"/"completed" are
  derived from the existing `hearingDateTime` field plus an assumed
  30-minute hearing length (`DEFAULT_HEARING_DURATION_MINUTES`) — a
  documented client-side approximation, not a new schema field.

**Changed (minimal, additive, reuses existing functions)**
- `hearings.js` now recognizes two more URL entry points alongside the
  existing, unchanged `?openHearing=<id>` (which Calendar still uses
  as-is): `?previewHearing=<id>` calls the existing `openPreview()`
  (the Quick View / "Lightbox" modal from v0.7.1) instead of the edit
  form — this is what the new Timeline and Session cards link to, so
  clicking a hearing on Home opens the same Lightbox rather than
  navigating to the edit form. `?action=add` calls the existing
  `openAddForm()` — this is what the new "Add Hearing" quick action uses.
  No form, validation, save, delete, or preview logic was duplicated;
  both are thin new checks in the existing `maybeAutoOpenFromUrl()`/`init()`
  functions.
- `home.js` now also calls `subscribeToCases()` from `hearings-data.js` —
  the exact same function `hearings.js` already uses — solely so "Export
  Today's Calendar" has case data to include. No new Firestore access code
  was written; this is the same reusable subscription helper called a
  second time, the same pattern already used for `subscribeToHearings()`
  across Home/Hearings/Calendar. "Export Today's Calendar" itself calls
  the existing `exportCourtCalendarForDate()` from `docx-export.js` (the
  same function the Hearings page's date-export already uses) with
  today's date — no export logic duplicated. `docx@8.0.4` script tag
  added to `home.html` (same version already used on `hearings.html`).

**Not changed:** Firestore schema, security rules, CRUD logic,
authentication flow, Calendar (page, `calendar.js`, or `calendar-data.js`),
Word Export document builder, Court Calendar Export logic, or Search.
Calendar's own `?openHearing=<id>` linking behavior is untouched.
Confirmed by checksum: `hearings-data.js`, `calendar-data.js`, `calendar.js`,
`nav-auth.js`, `firebase-init.js`, `firebase-config.js`, `auth-guard.js`,
`diagnostics.js`, `login.js`, `index.js`, `docx-export.js`,
`export-data.js`, `constants.js`, and `dashboard-stats.js` are all
byte-identical to v0.7.2 — only `home.html`, `js/home.js`, `js/hearings.js`,
and `css/styles.css` were modified, plus the new `js/dashboard-live.js`.

## [0.7.2] — Today's Hearings Panel

**Added**
- A read-only "Today's Hearings" card on `home.html`, below the dashboard
  summary cards. Lists every hearing scheduled for today, sorted
  chronologically, each showing time, "Plaintiff vs. Accused", and the
  hearing's stage/status.
- `getTodaysHearingsSorted()` (new, in `dashboard-stats.js`) — pure
  function, no Firestore/DOM. Filters to today's date and sorts by the
  existing `hearingDateTime` field (the derived Timestamp added in
  Milestone 3 specifically for sorting), rather than parsing the
  `hearingTime` label string.
- Reuses the **same** `subscribeToHearings()` call already added for the
  dashboard in v0.7.0 — one listener now drives both the stat cards and
  this new panel, not two.
- Displayed time is formatted from `hearingDateTime` (e.g. "8:30 AM")
  rather than the stored descriptive label ("8:30 in the Morning"), to
  match the requested display format — still derived entirely from
  existing data, no schema change.
- Clicking a hearing navigates to `hearings.html?openHearing=<id>` — the
  exact same mechanism Calendar already uses. Deliberately **not**
  changed to open the newer Quick View modal (from v0.7.1) instead: that
  URL parameter is shared with Calendar, and changing what it does would
  be a behavior change to Calendar, which this milestone requires to stay
  unchanged. Documented here in case a lightbox-on-click behavior is
  wanted later via a separate mechanism.
- Shows "No hearings scheduled today." when empty.

**Not changed:** Firestore schema, security rules, CRUD logic,
authentication flow, Calendar, Export, Search, or the Hearing Quick View.
Confirmed by checksum: `hearings-data.js`, `calendar-data.js`,
`calendar.js`, `hearings.js`, `nav-auth.js`, `firebase-init.js`,
`firebase-config.js`, `auth-guard.js`, `diagnostics.js`, `login.js`,
`index.js`, `docx-export.js`, `export-data.js`, and `constants.js` are
all byte-identical to before this release — only `home.html`, `js/home.js`,
`js/dashboard-stats.js`, and `css/styles.css` were touched.

**Frozen:** No further changes without a discovered bug.

## [0.7.1] — Hearing Quick View

**Added**
- Clicking anywhere on a hearing's row (outside its Edit/Delete buttons)
  opens a read-only quick-view modal showing every hearing field and its
  linked cases — reusing the already-loaded `hearings`/`cases` state via
  the existing `casesForHearing()` helper. No new Firestore read happens
  to open it.
- Closes via the X button, an outside click on the backdrop, or Escape.
- A convenience "Edit This Hearing" button in the modal closes the
  preview and calls the existing `openEditForm()` unchanged — no
  save/validation/delete logic is duplicated.
- Visually matches the existing design system (same tokens as the
  Firebase fatal-error overlay's card/overlay pattern) and adapts
  automatically to dark mode, since no new colors were introduced —
  every rule uses existing CSS custom properties.

**How it avoids double-triggering with existing row actions:** the row's
click handler checks `e.target.closest('[data-action]')` and bails out
before opening the preview, so the Edit and Delete buttons — unchanged —
keep working exactly as before.

**Not changed:** Firestore schema, security rules, CRUD logic,
authentication flow, Calendar, Export, Dashboard, or Search. Confirmed by
checksum: `hearings-data.js`, `calendar-data.js`, `calendar.js`,
`home.js`, `nav-auth.js`, `firebase-init.js`, `firebase-config.js`,
`auth-guard.js`, `diagnostics.js`, `login.js`, `index.js`,
`docx-export.js`, `export-data.js`, `constants.js`, and
`dashboard-stats.js` are all byte-identical to before this release —
only `hearings.js`, `hearings.html`, and `css/styles.css` were touched.

**Frozen:** No further changes without a discovered bug.

## [0.7.0] — Dashboard and Global Search

**Added — Dashboard (`home.html`)**
- Four read-only summary cards: Active Cases, Hearings Today, Hearings in
  Next 7 Days, Hearings in Next 30 Days.
- `js/dashboard-stats.js` (new) — pure computation only, no Firestore or
  DOM. Takes an already-loaded hearings array and returns the four
  numbers. "Active Cases" sums each hearing's existing `caseCount` field
  (added in Milestone 3 for exactly this purpose) — no new read of the
  `hearingCases` collection is needed for any of the four stats.
- `js/home.js` now calls `subscribeToHearings()` — the same function
  `hearings.js` already uses from `hearings-data.js` — rather than
  writing a second, duplicate Firestore query. Updates live whenever
  Firestore changes, same as every other consumer of that function.
- `home.html` widened from `wrap-narrow` to the existing `wrap-wide`
  container (already used on Hearings/Calendar) to fit the new grid; no
  new colors, fonts, or component styles were introduced.

**Added — Global Search (`hearings.html`)**
- A search bar filtering the Hearings table live as you type, across
  case number, plaintiff, accused, charge, hearing date, and status.
- Case-insensitive substring match against the already-loaded `hearings`/
  `cases` arrays in memory — filters client-side on every keystroke, with
  zero new Firestore queries. Reuses the existing `casesForHearing()`
  helper rather than duplicating any case-lookup logic.
- Search state is independent of Calendar and Export — neither was
  touched, and both continue reading the same underlying data untouched.

**Not changed:** Firestore schema, security rules, CRUD logic,
authentication flow, Calendar, or Export. Confirmed by checksum:
`hearings-data.js`, `calendar-data.js`, `calendar.js`, `nav-auth.js`,
`firebase-init.js`, `firebase-config.js`, `auth-guard.js`,
`diagnostics.js`, `login.js`, `index.js`, `docx-export.js`,
`export-data.js`, and `constants.js` are all byte-identical to before
this release.

**Frozen:** No further changes without a discovered bug.

## [0.6.3] — Export Dropdown + Circular Import Fix

**Fixed**
- **Circular import**, likely the actual cause of the export buttons not
  working: `hearings.js` imports `docx-export.js`, which imports
  `export-data.js`, which imported `SECTIONS` back from `hearings.js` —
  a cycle. New `js/constants.js` (no dependencies of its own) now holds
  `SECTIONS`; both `hearings.js` and `export-data.js` import it from
  there instead, so the graph is a clean, one-directional chain with no
  cycle.

**Changed**
- The three toolbar export controls (Export Date / Week / Month) are now
  a single "Export Calendar" dropdown button instead of three separate
  buttons + a bare date input, for a cleaner toolbar. All underlying IDs
  (`exportDateInput`, `exportDateBtn`, `exportWeekBtn`, `exportMonthBtn`)
  and their click handlers are unchanged — only the surrounding markup
  and a new open/close toggle were added. The menu closes automatically
  on a successful export, on Escape, or on an outside click.

**Not changed:** Firestore schema, security rules, CRUD logic,
authentication flow, Calendar, or the document-generation logic itself
(same shared builder from v0.6.2). Confirmed by checksum:
`hearings-data.js`, `calendar-data.js`, `calendar.js`, `home.js`,
`nav-auth.js`, `firebase-init.js`, `firebase-config.js`, `auth-guard.js`,
`diagnostics.js`, `login.js`, and `index.js` are all byte-identical to
before this release.

**Frozen:** No further changes without a discovered bug.

## [0.6.2] — Court Calendar Export System

Generalizes Word export from a single-hearing-only feature into a proper
multi-mode export service, matching the previous Branch system's actual
Court Calendar export behavior.

**Added**
- `js/export-data.js` (new) — pure data-preparation layer. No Firestore,
  no docx, no DOM. Filters the already-loaded `hearings`/`cases` arrays by
  date/week/month, attaches each hearing's own cases, and groups the
  result by section (canonical order, from `hearings.js`'s now-exported
  `SECTIONS` constant) — the exact renderer-agnostic shape a future PDF
  exporter could also consume.
- Three new export modes in the Hearings toolbar: **Export Date** (date
  picker + button), **Export Week**, **Export Month** — all reuse the
  page's already-loaded `hearings`/`cases` state; none trigger a new
  Firestore read.
- `js/docx-export.js` — reorganized around **one shared builder**
  (`buildCourtCalendarChildren`) that every export mode calls, differing
  only in which hearings are in the dataset. "Export This Hearing" is now
  a thin wrapper that prepares a one-item dataset and calls the same
  builder as the other three modes — no document-generation logic is
  duplicated between modes.
- Document title is now "COURT CALENDAR" for every mode (matching the
  real reference document exactly), with a mode-specific subtitle
  ("Hearing on...", "For...", "Week of...", "Month of...").

**Changed**
- `hearings.js` now exports `SECTIONS` (was a local `const`) so
  `export-data.js` can reuse the canonical section order instead of
  duplicating it.
- Removed all temporary `[docx-diagnostic]` console logging and the
  `window.__docxDiagnosticTest()` helper added during the earlier blank-
  export investigation — that issue is resolved (see the `docx@8.0.4` +
  `defer` fixes below), so this cleanup keeps the file focused on the new
  feature rather than leftover debugging scaffolding.
- **Fixed a real bug caught before shipping:** the new toolbar export
  buttons have icon children, and the button-state helper was initially
  written using `textContent` to save/restore their label during
  "Exporting…" — which would have silently deleted the icon after the
  first click (`textContent` only sees text nodes, not the `<i>` icon
  element). Corrected to use `innerHTML`, the same safe pattern already
  used elsewhere in this codebase for icon-bearing buttons.

**Not changed:** Firestore schema, security rules, CRUD logic,
authentication flow, or Calendar. Confirmed by checksum: `hearings-data.js`,
`calendar-data.js`, `calendar.js`, `home.js`, `nav-auth.js`,
`firebase-init.js`, `firebase-config.js`, `auth-guard.js`, `diagnostics.js`,
`login.js`, and `index.js` are all byte-identical to before this release.

**Frozen:** No further changes without a discovered bug.

## [0.6.1] — Mobile Header & Branding (No Feature Changes)

UI-only polish. No `.js` file was modified — verified by checksum before
and after. No backend logic, Firestore schema, CRUD behavior, security
rules, Calendar logic, or Word export/formatting changed.

**Fixed**
- Nav bar is now fully responsive below ~768px, CSS-only (`css/styles.css`
  only — no HTML changed for this part, and no ID/class was renamed):
  - Below 768px, the nav wraps onto two rows: brand + email + Logout on
    row one, nav links on their own full-width row below (wrapping
    internally too, if ever needed).
  - The brand name uses `flex: 1 1 auto` + `min-width: 0` + ellipsis, so
    it shrinks and truncates to fit whatever space remains — deliberately
    avoiding fixed-width/viewport-unit math that would need retuning for
    every screen size.
  - The signed-in email gets a `max-width` + ellipsis, so it truncates
    rather than overflowing or pushing Logout off-screen.
  - The Logout button reserves its own space (`flex-shrink: 0`) and
    always stays fully visible and tappable.
  - The Hearings table's sticky header (tuned for the desktop nav's fixed
    height) switches to normal, non-sticky positioning below 768px, since
    the mobile nav's height is no longer fixed — this avoids the table
    header sticking at the wrong offset or overlapping the wrapped nav.
  - Desktop layout (>768px) is completely unaffected — every change lives
    inside a single `@media (max-width: 768px)` block.

**Added**
- "Created by Jordan Panganiban" — a small, muted footer line at the
  bottom of the main content on Home, Hearings, and Calendar. Uses
  existing color/spacing tokens (`--ink-3`, `--text-xs`, `--space-8`).
  New `.app-footer` class only; sits outside every dynamically-rendered
  container (`#calendarContent`, `#hearingsTableBody`, `#formPanel`), so
  it's never touched or overwritten by any existing re-render logic.

**Not changed:** Firestore schema, security rules, CRUD logic,
authentication flow, Calendar logic, Word export, or export formatting.
All 11 `.js` files confirmed byte-identical to before this release by
checksum. Only `css/styles.css`, `home.html`, `hearings.html`, and
`calendar.html` were touched.

**Frozen:** No further changes without a discovered bug.

## [0.6.0] — Hearing Order (.docx) Export

**Added**
- One "Export to Word" button, shown only when editing an existing
  hearing on `hearings.html`. Generates a real, Word-editable `.docx` file
  for that single hearing and downloads it immediately.
- `js/docx-export.js` — new, fully isolated document-generation module.
  No Firestore or auth imports; its only inputs are the hearing object
  and case list already loaded in `hearings.js`'s own state (via the
  existing `casesForHearing()` helper) — no new Firestore query is made
  to produce an export.
- Uses the `docx` library (docx.js.org) loaded via CDN in `hearings.html`,
  pinned to v5.0.2 specifically — later major versions restructured
  their package around ES module exports and no longer reliably expose a
  plain `window.docx` global from a single `<script>` tag with no
  bundler, which this project requires.

**Replicates the Branch's real Hearing Order/Calendar document format**
(source: the uploaded reference file), not a generic report:
- Full letterhead — court name, branch, address, presiding judge, and the
  court personnel list, all hardcoded (this data has no home in Firestore;
  it's static institutional information, not per-hearing data)
- The same shaded, bordered 6-column table layout (`#`, `CASE NO(S). /
  DETAILS`, `TITLE / VICTIM(S)`, `FOR / CHARGE`, `COUNSEL`, `STATUS /
  HEARING`), populated with one row for the single exported hearing
  instead of a full multi-hearing calendar

**Two deliberate deviations from the original v0.6.0 brief**, both
because "replicate this document exactly" (given after the brief) is the
more specific, later instruction:
- Font is **Century Schoolbook** (the real document's font), not Times
  New Roman as originally specified.
- Page size is **Legal (8.5in × 14in)** with 1in/0.75in/1in/0.75in
  margins (top/right/bottom/left), matching the real document, rather
  than a generic "standard" Letter-size margin.

**Known gap:** the reference document includes per-case notification/
private-complainant status lines (e.g. "PCAAA C/O ..."). That data
(`pcInfo` / `accusedNotifiedStatus`) was a deliberate simplification
dropped from this system's schema back in Milestone 3 and doesn't exist
here — those lines are simply omitted from the export rather than
fabricated.

**Not changed:** Firestore schema, security rules, CRUD behavior,
authentication flow, Calendar, or any other UI. Confirmed by checksum:
`hearings-data.js`, `calendar-data.js`, `calendar.js`, `home.js`,
`nav-auth.js`, `firebase-init.js`, `firebase-config.js`, `auth-guard.js`,
`diagnostics.js`, `login.js`, and `index.js` are all byte-identical to
before this release. Only `hearings.html` and `js/hearings.js` were
modified, plus the new `js/docx-export.js`.

**Frozen:** No further changes without a discovered bug.

## [0.5.1] — Logout everywhere, Lucide hardening, automatic dark mode

**Added**
- `js/nav-auth.js` — new shared helper, `wireNavAuth(user)`. Does not
  duplicate authentication logic: `auth-guard.js`'s `requireAuth()` remains
  the only function that calls `onAuthStateChanged`, unchanged. This
  helper only wires the nav bar's email display and Logout button once a
  page already has the user object `requireAuth()` resolved — in one
  place instead of copy-pasted into every page.
- Automatic Dark Mode via `prefers-color-scheme: dark` — follows OS
  preference only, no manual toggle. All theme differences live entirely
  inside the single existing `@media (prefers-color-scheme: dark)` token
  block; no component rule was duplicated.

**Changed**
- `js/home.js` — refactored to call `wireNavAuth(user)` instead of its own
  inline email/logout wiring (same behavior, now shared).
- `js/hearings.js`, `js/calendar.js` — one import + one function call each
  (`wireNavAuth(user)`), added right after `requireAuth()` resolves.
- `hearings.html`, `calendar.html` — nav bar now includes the signed-in
  email and a working Logout button, matching `home.html`.
- Lucide init calls on `home.html`/`hearings.html`/`calendar.html` now
  guard against the CDN failing to load (`if (window.lucide) { ... }`),
  so a blocked network fails silently instead of throwing to the console.
  Verified every `data-lucide` element on every page appears before its
  page's Lucide script tag in document order, so `createIcons()` always
  finds them.
- **Fixed three dark-mode bugs found during implementation**, all in
  `css/styles.css`:
  - `.app-nav` and the nav's signature gradient hairline used `var(--ink)`
    for their background — since `--ink` flips to a *light* color in dark
    mode, this would have made the nav bar background light while its
    text stayed hardcoded white, i.e. invisible. Introduced `--nav-bg`
    (intentionally constant across both themes) and pointed the nav and
    `.cal-view-btn-active` (same bug) at it instead.
  - Table zebra-striping and row-hover tints were hardcoded dark-navy-
    and-brass rgba() values — invisible when layered on an
    already-dark card in dark mode. Replaced with `--zebra-tint`/
    `--row-hover-tint` tokens, each with a dark-mode override.
  - Status colors (`--green`/`--amber`/`--red`/`--blue`) and
    `--brass-dark` (used for links and hover text) are now brightened in
    dark mode for stronger contrast against the much darker backgrounds —
    override lives in the existing dark-mode token block only.

**Not changed:** Firestore schema, security rules, CRUD behavior, or the
authentication flow. Confirmed by checksum: `hearings-data.js`,
`calendar-data.js`, `firebase-init.js`, `firebase-config.js`,
`auth-guard.js`, `diagnostics.js`, `login.js`, and `index.js` are all
byte-identical to before this release.

**Frozen:** No further changes without a discovered bug.

## [0.5.0] — UI Foundation Redesign

HTML/CSS only. No JavaScript file was modified — verified by checksum
before and after. No backend logic, Firestore schema, CRUD behavior,
security rules, or authentication flow changed.

**Added — Design system (`css/styles.css`, full rewrite)**
- Color tokens (navy ink, brass/gold primary action color, sparing maroon
  accent, warm paper background), a two-role type scale (Source Serif 4
  for headings, Inter for everything else), consistent spacing/radius/
  shadow scales
- Persistent top navigation bar (new, on `home.html`/`hearings.html`/
  `calendar.html`) with active-page highlighting and a signature
  navy-to-brass-to-maroon hairline beneath it
- Redesigned buttons, form inputs, cards, and the Firebase fatal-error
  overlay, all using the new tokens
- Tables optimized for daily use: sticky header (stays visible while
  scrolling a long hearings list), zebra striping, row hover, tabular
  figures for aligned dates/case numbers, comfortable padding
- Lightweight icons via Lucide (CDN): real `<i data-lucide>` icons on
  static nav/toolbar elements (rendered once via `lucide.createIcons()`
  on page load); CSS-only mask-image icons (in Lucide's visual style) on
  every dynamically-rendered element from `hearings.js`/`calendar.js`/
  `diagnostics.js` — since `createIcons()` only runs once at load and
  never against content those scripts generate afterward, embedding a
  real `<i>` tag there would silently never become an icon

**Fixed one self-inflicted risk before it shipped:** the login submit
button's icon was initially added as a real child element, then corrected
to a CSS `::before` pseudo-element instead, because `login.js` sets that
button's `.textContent` directly during sign-in — a real child element
would have been wiped out by that on first use. Pseudo-elements aren't
part of the DOM `.textContent` touches, so this survives untouched, with
zero changes to `login.js`.

**Known, deliberate limitation:** only `home.js` wires up `logoutBtn`'s
click handler and populates `userEmail` — `hearings.js` and `calendar.js`
do neither. Adding those same elements to the Hearings/Calendar nav bars
would have created a non-functional button. Their nav bars therefore
include Home/Hearings/Calendar links only; logging out requires returning
to Home first.

**Files touched:** `css/styles.css`, `index.html`, `login.html`,
`home.html`, `hearings.html`, `calendar.html`. `diagnostics.html` needed
no changes — it already used classes the new stylesheet restyles
automatically. **No `.js` file was touched** (verified by checksum).

**Frozen:** No further changes without a discovered bug.

## [0.4.1] — Production readiness fixes

Fixes three issues found during a production-readiness review of v0.4.0.
No new features; no changes to the authentication architecture.

**Fixed**
- **Real entry point restored.** `index.html` (the site's root page) no
  longer shows the Milestone 1 developer diagnostics screen. It now
  immediately redirects: signed-in users → `home.html`, signed-out users →
  `login.html`. The diagnostics screen still exists — moved to
  `diagnostics.html` (script renamed to `js/diagnostics.js`) — but is no
  longer linked from anywhere in the Clerk-facing app. `js/index.js` reuses
  the existing `requireAuth()` from `auth-guard.js` rather than adding any
  new auth logic.
- **Login form validation restored.** Removed the `novalidate` attribute
  from `login.html`, which had been silently disabling the browser's
  native required-field checks despite both inputs being marked
  `required`. Also added a small defensive check in `js/login.js` so an
  empty email or password can never reach Firebase even if the submit
  event fires some other way. Friendly error messages for actual bad
  credentials are unchanged.
- **Graceful Firebase initialization failure handling.** `js/auth-guard.js`
  now checks for `firebaseInitError` (from `firebase-init.js`) before
  calling `onAuthStateChanged`. If Firebase failed to initialize, every
  page that depends on it — `index.html`, `login.html`, `home.html`,
  `hearings.html`, `calendar.html` — now shows a clear, user-facing
  "Unable to connect" overlay instead of a blank page or an uncaught
  exception. `diagnostics.html` already had its own equivalent handling
  from Milestone 1 and needed no change. This is the same two guard
  functions as before (`requireAuth`, `redirectIfAuthenticated`) with a
  guarded early return — no new authentication flow was introduced.

**Not changed:** everything else found in the production review (Firestore
query patterns, duplicated helper functions, stale comments, session
re-validation mid-session, etc.) — those were reported but explicitly not
authorized for this fix batch.

## [0.4.0] — Milestone 4: Calendar Views

**Added**
- `calendar.html` + `js/calendar.js` — Month, Week, and Day views with
  Prev/Next/Today navigation, toggled within a single page
- `js/calendar-data.js` — strictly read-only Firestore access layer for
  Calendar; queries `hearings` by date range on `hearingDateTime`
  (added in Milestone 3), never loads the full collection
- Month and Week views use the existing `caseCount` field for counts —
  neither ever queries `hearingCases`
- Day View loads only hearing documents up front; a specific hearing's
  case numbers are fetched from `hearingCases` only when the Clerk clicks
  "Show cases" on that hearing, and cached per-session so re-expanding
  doesn't refetch
- Clicking a hearing anywhere in Calendar (Month entry, Week entry, or a
  Day card's "Details" link) navigates to `hearings.html?openHearing=<id>`,
  which reuses the existing edit form there — Calendar itself contains no
  form, validation, save, or delete logic
- Clicking a Month cell's date (not a specific entry) drills into Day View
  for that date
- Navigation link to Calendar added on `home.html`, alongside the existing
  Hearings link

**Not included (by design, scoped to later milestones)**
- Color coding, filters, drag-and-drop scheduling, printable calendar
  views — the implementation is structured (pure date helpers, one render
  function per view, isolated data layer) so these can be added later
  without rewriting the core calendar
- No schema changes, no new collections, no composite indexes required

**Frozen:** No further changes without a discovered bug.

## [0.3.3] — Milestone 3 bugfix: Duplicate check now ignores deleted hearings

**Fixed**
- The duplicate case-number check previously scanned all `hearingCases`
  documents regardless of whether their parent hearing was soft-deleted,
  so a case number that existed only on a deleted hearing would still
  (incorrectly) trigger the "already exists" warning. `isDuplicateCaseNumber()`
  now accepts the set of currently active (non-deleted) hearing IDs and
  skips cases belonging to any hearing outside that set.

**Scope of change:** `js/hearings-data.js` (function signature) and
`js/hearings.js` (its one call site) only. No other function, file, schema
field, CRUD behavior, soft-delete mechanics, audit fields, `caseCount`, or
`hearingDateTime` logic was touched. No UI changes.

**Frozen permanently.** Milestone 3 validated and production-ready. No
further changes without a discovered bug.

## [0.3.2] — Milestone 3 revision: Computed hearingDateTime

**Added**
- `hearingDateTime` — a derived Firestore Timestamp on each hearing
  document, computed from the existing `hearingDate` and `hearingTime`
  fields on every save. Nobody edits it directly; `hearingDate` and
  `hearingTime` remain the source of truth. Added to simplify future
  Calendar, Dashboard, Search, and sorting features that need a single
  sortable/queryable timestamp instead of two separate string fields.

**Not changed:** `hearingDate` and `hearingTime` fields, existing
functionality, schema shape (still two flat collections, no new
collections).

**Frozen permanently.** Milestone 3 is complete. No further changes without
a discovered bug.

## [0.3.1] — Milestone 3 revision: Soft Delete, Audit Fields, Case Count

**Changed**
- Hearing deletion is now a **soft delete**: `deleteHearing()` sets
  `isDeleted`, `deletedAt`, and `deletedBy` on the hearing document instead
  of removing it. The UI still shows a "Delete" button and the hearing
  disappears from the list (the list query filters out `isDeleted` hearings),
  but the record — and its attached cases — remain in Firestore,
  recoverable. Removing an individual case row during an edit (not
  deleting the whole hearing) is still a real delete, since that's a
  routine data correction rather than the case this revision protects
  against.
- Both `hearings` and `hearingCases` documents now carry full audit
  fields: `createdAt`, `updatedAt`, `createdBy`, `updatedBy` (the last two
  populated from the signed-in user's email).
- Each hearing document now stores `caseCount` (recomputed on every save),
  so future screens can show the number of linked cases without querying
  and counting `hearingCases` documents.

**Not changed:** schema stays two flat collections — no new collections,
no normalization.

**Frozen:** No further changes without a discovered bug.

## [0.3.0] — Milestone 3: Core Hearing Management

**Added**
- `hearings.html` + `js/hearings.js` — list of all hearings, add/edit form
  with dynamic case-number rows, delete
- `js/hearings-data.js` — Firestore data access layer for the `hearings`
  and `hearingCases` collections (the only file that reads/writes them)
- Required-field validation (hearing type, accused, hearing date, at least
  one case number)
- Duplicate case-number warning (checks case type + case number across all
  hearings, with a confirm-to-proceed override)
- Firestore Security Rules updated: `hearings` and `hearingCases` now
  require `request.auth != null` for read and write
- Small navigation link from `home.html` to `hearings.html` (plain link,
  not a dashboard widget)

**Not included (by design, scoped to later milestones)**
- Calendar, Dashboard, Search, Printing, Reports, User Management, Roles,
  Notifications, Analytics

**Frozen:** No further changes without a discovered bug.

## [0.2.0] — Milestone 2: Authentication

**Added**
- Firebase Authentication (Email/Password) wired in via the v9+ modular SDK
- `login.html` — login form with client-side required-field validation
- `home.html` — minimal authenticated placeholder page (system title,
  signed-in user's email, welcome message, logout button only — no
  dashboard content)
- `js/auth-guard.js` — shared `requireAuth()` / `redirectIfAuthenticated()`
  route-guarding module, structured so future role/permission checks can be
  added without changing how pages call it
- `js/login.js` — sign-in logic, friendly error messages for common
  Firebase Auth error codes, disabled/loading button state during sign-in
- `js/home.js` — auth guard + logout wiring for the home page
- Session persistence via `browserLocalPersistence`

**Not included (by design, scoped to later milestones)**
- Dashboard content (Milestone 5)
- Roles/permissions (not in V1 scope)
- Any Firestore reads/writes beyond Milestone 1's read-only status check

**Frozen:** No further changes without a discovered bug.

## [0.1.0] — Milestone 1: Project Setup

**Added**
- Project folder structure (`css/`, `js/`)
- Firebase v9+ modular SDK wiring (`js/firebase-config.js`,
  `js/firebase-init.js`)
- `index.html` — status page confirming Firebase config, app
  initialization, and a read-only Firestore connectivity check (no test
  documents written)
- GitHub Pages deployment process documented in `README.md`

**Frozen:** No further changes without a discovered bug.
